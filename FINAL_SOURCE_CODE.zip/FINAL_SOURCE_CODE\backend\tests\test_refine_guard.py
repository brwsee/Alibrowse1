from app.metrics import Metrics
from app.pipeline import TranscriptionPipeline
from app.segmenter import Paragraph
from app.stt.fake_provider import FakeRefiner


def _pipeline(settings, refiner):
    return TranscriptionPipeline(settings, None, None, None, refiner, Metrics())


def test_refiner_accepts_small_edits(settings):
    p = [Paragraph(0, 1000, None, "raw", "انا رايح المدرسه بكره")]
    pipe = _pipeline(settings, FakeRefiner(lambda ps: ["أنا رايح المدرسة بكرة."]))
    assert pipe._refine(p) is True
    assert p[0].text == "أنا رايح المدرسة بكرة."


def test_refiner_rejects_hallucination(settings):
    original = "انا رايح المدرسه بكره"
    p = [Paragraph(0, 1000, None, "raw", original)]
    pipe = _pipeline(settings, FakeRefiner(lambda ps: ["سأذهب غداً إلى الجامعة لحضور محاضرة مهمة جداً عن الفيزياء."]))
    assert pipe._refine(p) is False
    assert p[0].text == original


def test_refiner_wrong_count_is_ignored(settings):
    p = [Paragraph(0, 1, None, "a", "نص اول"), Paragraph(2, 3, None, "b", "نص ثاني")]
    pipe = _pipeline(settings, FakeRefiner(lambda ps: None))
    assert pipe._refine(p) is False
