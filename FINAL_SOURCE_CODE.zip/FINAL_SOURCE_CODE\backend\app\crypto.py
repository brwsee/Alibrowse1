"""تشفير الظرف (Envelope Encryption) — يطابق تماماً تنفيذ العميل في
mobile/lib/services/crypto_service.dart.

صيغة الملف المشفّر SKL1:
    header (21 bytes) = b"SKL1" | version(1) | chunk_size(uint32 BE) | base_nonce(12)
    ثم لكل مقطع i: AES-256-GCM(plain_i) || tag(16)
        nonce_i = base_nonce[:8] || (uint32(base_nonce[8:]) XOR i)
        aad_i   = header || uint32_be(i) || (0x01 إن كان المقطع الأخير وإلا 0x00)
علامة "المقطع الأخير" في AAD تمنع هجمات الاقتطاع (truncation)، والتشفير المقطعي
يسمح بالتشفير المتدفق دون تحميل الملف كاملاً في الذاكرة.

مفتاح البيانات DEK (32 بايت عشوائي لكل جزء) يُغلَّف بـ RSA-OAEP-SHA256 بالمفتاح العام للخادم.
في الإنتاج يُستبدل KeyManager بـ Cloud KMS (المفتاح الخاص لا يغادر الـ HSM).
"""
from __future__ import annotations

import base64
import hashlib
import os
from pathlib import Path

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

MAGIC = b"SKL1"
VERSION = 1
HEADER_LEN = 21
TAG_LEN = 16
DEFAULT_CHUNK = 64 * 1024

_OAEP = padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None)


class CryptoError(Exception):
    pass


def _b64url_uint(n: int) -> str:
    raw = n.to_bytes((n.bit_length() + 7) // 8, "big")
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode()


def _nonce(base: bytes, i: int) -> bytes:
    return base[:8] + (int.from_bytes(base[8:], "big") ^ i).to_bytes(4, "big")


class KeyManager:
    def __init__(self, keys_dir: Path):
        keys_dir.mkdir(parents=True, exist_ok=True)
        path = keys_dir / "upload_rsa.pem"
        if path.exists():
            self._priv = serialization.load_pem_private_key(path.read_bytes(), password=None)
        else:
            self._priv = rsa.generate_private_key(public_exponent=65537, key_size=3072)
            path.write_bytes(
                self._priv.private_bytes(
                    serialization.Encoding.PEM,
                    serialization.PrivateFormat.PKCS8,
                    serialization.NoEncryption(),
                )
            )
            try:
                os.chmod(path, 0o600)
            except OSError:
                pass
        pub_der = self._priv.public_key().public_bytes(
            serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo
        )
        self.key_id = hashlib.sha256(pub_der).hexdigest()[:16]

    def public_jwk(self) -> dict:
        nums = self._priv.public_key().public_numbers()
        return {"kty": "RSA", "alg": "RSA-OAEP-256", "use": "enc", "kid": self.key_id,
                "n": _b64url_uint(nums.n), "e": _b64url_uint(nums.e)}

    def public_key(self):
        return self._priv.public_key()

    def unwrap(self, wrapped_b64: str, key_id: str) -> bytes:
        if key_id != self.key_id:
            raise CryptoError("unknown key id")
        try:
            dek = self._priv.decrypt(base64.b64decode(wrapped_b64), _OAEP)
        except Exception as exc:  # noqa: BLE001
            raise CryptoError("cannot unwrap data key") from exc
        if len(dek) != 32:
            raise CryptoError("invalid data key length")
        return dek


def wrap_key(public_key, dek: bytes) -> str:
    return base64.b64encode(public_key.encrypt(dek, _OAEP)).decode()


def encrypt_bytes(plain: bytes, dek: bytes, chunk_size: int = DEFAULT_CHUNK, base_nonce: bytes | None = None) -> bytes:
    """مرآة لتنفيذ العميل — تُستخدم في الاختبارات وأدوات التشخيص."""
    base_nonce = base_nonce or os.urandom(12)
    header = MAGIC + bytes([VERSION]) + chunk_size.to_bytes(4, "big") + base_nonce
    aes = AESGCM(dek)
    chunks = [plain[i:i + chunk_size] for i in range(0, len(plain), chunk_size)] or [b""]
    out = bytearray(header)
    for i, chunk in enumerate(chunks):
        last = i == len(chunks) - 1
        aad = header + i.to_bytes(4, "big") + (b"\x01" if last else b"\x00")
        out += aes.encrypt(_nonce(base_nonce, i), chunk, aad)
    return bytes(out)


def decrypt_file(src: Path, dst: Path, dek: bytes) -> int:
    """فك تشفير متدفق؛ يعيد عدد بايتات النص الصريح. يرفع CryptoError عند أي عبث."""
    aes = AESGCM(dek)
    written = 0
    with open(src, "rb") as f, open(dst, "wb") as out:
        header = f.read(HEADER_LEN)
        if len(header) != HEADER_LEN or header[:4] != MAGIC or header[4] != VERSION:
            raise CryptoError("bad header")
        chunk_size = int.from_bytes(header[5:9], "big")
        if not 1024 <= chunk_size <= 16 * 1024 * 1024:
            raise CryptoError("bad chunk size")
        base_nonce = header[9:21]
        enc_len = chunk_size + TAG_LEN
        i = 0
        cur = f.read(enc_len)
        if len(cur) < TAG_LEN:
            raise CryptoError("truncated")
        while True:
            nxt = f.read(enc_len)
            last = len(nxt) == 0
            aad = header + i.to_bytes(4, "big") + (b"\x01" if last else b"\x00")
            try:
                plain = aes.decrypt(_nonce(base_nonce, i), cur, aad)
            except Exception as exc:  # noqa: BLE001
                raise CryptoError(f"authentication failed at chunk {i}") from exc
            out.write(plain)
            written += len(plain)
            if last:
                return written
            cur = nxt
            i += 1
