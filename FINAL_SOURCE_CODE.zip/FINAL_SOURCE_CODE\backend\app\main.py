from __future__ import annotations

import json
import logging
import time
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request, Response
from prometheus_client import CONTENT_TYPE_LATEST, generate_latest

from .auth import issue_token
from .config import Settings
from .crypto import KeyManager
from .db import make_session_factory
from .metrics import Metrics
from .pipeline import TranscriptionPipeline
from .routes import recordings, uploads
from .schemas import DevTokenIn
from .stt.base import SttProvider, TextRefiner


class JsonFormatter(logging.Formatter):
    """سجلات JSON منظمة (لا تُسجَّل أي نصوص مفرّغة أو بيانات صوتية — فقط معرّفات وأرقام)."""

    def format(self, record: logging.LogRecord) -> str:
        payload = {"ts": self.formatTime(record), "level": record.levelname, "logger": record.name,
                   "msg": record.getMessage()}
        for key in ("request_id", "path", "status", "duration_ms"):
            if hasattr(record, key):
                payload[key] = getattr(record, key)
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False)


def _configure_logging() -> None:
    root = logging.getLogger()
    if not any(isinstance(h.formatter, JsonFormatter) for h in root.handlers):
        handler = logging.StreamHandler()
        handler.setFormatter(JsonFormatter())
        root.addHandler(handler)
        root.setLevel(logging.INFO)


def _default_provider(settings: Settings) -> tuple[SttProvider, TextRefiner | None]:
    if settings.stt_provider == "fake":
        from .stt.fake_provider import FakeRefiner, FakeSttProvider
        return FakeSttProvider(), FakeRefiner()
    from .stt.gemini_provider import GeminiRefiner, GeminiSttProvider
    refiner = GeminiRefiner(settings.refine_model) if settings.refine_enabled else None
    return GeminiSttProvider(settings.stt_model), refiner


def create_app(
    settings: Settings | None = None,
    provider: SttProvider | None = None,
    refiner: TextRefiner | None = None,
) -> FastAPI:
    settings = settings or Settings.from_env()
    settings.ensure_dirs()
    _configure_logging()
    access_log = logging.getLogger("skl.access")

    if provider is None:
        provider, default_refiner = _default_provider(settings)
        refiner = refiner if refiner is not None else default_refiner

    session_factory = make_session_factory(settings.database_url)
    keys = KeyManager(settings.keys_dir)
    metrics = Metrics()
    pipeline = TranscriptionPipeline(settings, session_factory, keys, provider, refiner, metrics)

    @asynccontextmanager
    async def lifespan(_: FastAPI):
        pipeline.start()
        yield
        pipeline.stop()

    app = FastAPI(title="Smart Knowledge Library API", version="1.0.0", lifespan=lifespan)
    app.state.settings, app.state.session_factory = settings, session_factory
    app.state.keys, app.state.metrics, app.state.pipeline = keys, metrics, pipeline

    @app.middleware("http")
    async def request_log(request: Request, call_next):
        rid = request.headers.get("X-Request-ID") or str(uuid.uuid4())
        t0 = time.perf_counter()
        response = await call_next(request)
        response.headers["X-Request-ID"] = rid
        response.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains"
        access_log.info("request", extra={"request_id": rid, "path": f"{request.method} {request.url.path}",
                                          "status": response.status_code,
                                          "duration_ms": round((time.perf_counter() - t0) * 1000, 1)})
        return response

    app.include_router(uploads.router)
    app.include_router(recordings.router)

    @app.get("/healthz")
    def healthz() -> dict:
        return {"ok": True}

    @app.get("/metrics")
    def prom() -> Response:
        return Response(generate_latest(metrics.registry), media_type=CONTENT_TYPE_LATEST)

    @app.get("/v1/keys/upload")
    def upload_key() -> dict:
        return keys.public_jwk()

    @app.post("/v1/auth/dev-token")
    def dev_token(body: DevTokenIn) -> dict:
        if not settings.dev_mode:
            raise HTTPException(404)
        return {"token": issue_token(settings.jwt_secret, body.user_id, body.device_id)}

    return app


def __getattr__(name: str):  # `uvicorn app.main:app` — إنشاء كسول
    if name == "app":
        globals()["app"] = create_app()
        return globals()["app"]
    raise AttributeError(name)
