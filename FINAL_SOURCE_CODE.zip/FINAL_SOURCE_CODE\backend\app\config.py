from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Settings:
    data_dir: Path
    database_url: str
    jwt_secret: str
    dev_mode: bool = False
    max_upload_bytes: int = 1024 * 1024 * 1024  # 1 GiB per part
    max_chunk_bytes: int = 8 * 1024 * 1024  # 8 MiB per PATCH
    upload_ttl_hours: int = 72
    stt_provider: str = "gemini"  # gemini | fake
    stt_model: str = "gemini-3.5-transcribe"
    refine_model: str = "gemini-3.8-flash"
    refine_enabled: bool = True
    refine_max_drift_cer: float = 0.25  # reject LLM refinement that drifts too far from audio
    paragraph_pause_ms: int = 700
    paragraph_max_ms: int = 30_000
    worker_inline: bool = False  # tests: run transcription synchronously
    custom_vocabulary: list[str] = field(default_factory=list)

    @property
    def uploads_dir(self) -> Path:
        return self.data_dir / "uploads"

    @property
    def keys_dir(self) -> Path:
        return self.data_dir / "keys"

    @property
    def tmp_dir(self) -> Path:
        return self.data_dir / "tmp"

    @classmethod
    def from_env(cls) -> "Settings":
        data_dir = Path(os.getenv("SKL_DATA_DIR", "./data")).resolve()
        return cls(
            data_dir=data_dir,
            database_url=os.getenv("SKL_DATABASE_URL", f"sqlite:///{data_dir / 'skl.db'}"),
            jwt_secret=os.environ.get("SKL_JWT_SECRET", "dev-secret-change-me"),
            dev_mode=os.getenv("SKL_DEV_MODE", "0") == "1",
            stt_provider=os.getenv("SKL_STT_PROVIDER", "gemini"),
            refine_enabled=os.getenv("SKL_REFINE", "1") == "1",
            custom_vocabulary=[v for v in os.getenv("SKL_VOCAB", "").split("|") if v],
        )

    def ensure_dirs(self) -> None:
        for d in (self.data_dir, self.uploads_dir, self.keys_dir, self.tmp_dir):
            d.mkdir(parents=True, exist_ok=True)
