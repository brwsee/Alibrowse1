/// نماذج البيانات المحلية. «التسجيل» هو الكيان الموحد الذي يجمع الصوت (أجزاء) والميتا والتفريغ.
library;

enum RecStatus { recording, local, uploading, queued, transcribing, transcribed, failed }

extension RecStatusLabel on RecStatus {
  String get label => switch (this) {
        RecStatus.recording => 'قيد التسجيل',
        RecStatus.local => 'محفوظ محلياً',
        RecStatus.uploading => 'جارٍ الرفع',
        RecStatus.queued => 'بانتظار التفريغ',
        RecStatus.transcribing => 'جارٍ التفريغ',
        RecStatus.transcribed => 'مُفرَّغ',
        RecStatus.failed => 'فشل',
      };
}

RecStatus recStatusFrom(String s) => switch (s) {
      'pending' || 'local' => RecStatus.local,
      'uploading' => RecStatus.uploading,
      'queued' => RecStatus.queued,
      'transcribing' => RecStatus.transcribing,
      'transcribed' => RecStatus.transcribed,
      'failed' => RecStatus.failed,
      'recording' => RecStatus.recording,
      _ => RecStatus.local,
    };

class Recording {
  Recording({
    required this.id,
    required this.recordedAt,
    required this.codec,
    required this.sampleRate,
    this.title = '',
    this.durationMs = 0,
    this.latitude,
    this.longitude,
    this.placeName,
    this.dialectHint,
    this.status = RecStatus.recording,
    this.serverVersion = 0,
    this.dirty = false,
    this.metaSynced = false,
    this.deleted = false,
    this.hasConflict = false,
    this.formattedText,
    DateTime? updatedAt,
  }) : updatedAt = updatedAt ?? DateTime.now();

  final String id;
  String title;
  final DateTime recordedAt;
  int durationMs;
  final String codec;
  final int sampleRate;
  double? latitude;
  double? longitude;
  String? placeName;
  String? dialectHint;
  RecStatus status;
  int serverVersion;
  bool dirty; // تعديلات نصية محلية لم تُدفع
  bool metaSynced;
  bool deleted;
  bool hasConflict;
  String? formattedText;
  DateTime updatedAt;

  Map<String, Object?> toMap() => {
        'id': id,
        'title': title,
        'recorded_at': recordedAt.millisecondsSinceEpoch,
        'duration_ms': durationMs,
        'codec': codec,
        'sample_rate': sampleRate,
        'latitude': latitude,
        'longitude': longitude,
        'place_name': placeName,
        'dialect_hint': dialectHint,
        'status': status.name,
        'server_version': serverVersion,
        'dirty': dirty ? 1 : 0,
        'meta_synced': metaSynced ? 1 : 0,
        'deleted': deleted ? 1 : 0,
        'has_conflict': hasConflict ? 1 : 0,
        'formatted_text': formattedText,
        'updated_at': updatedAt.millisecondsSinceEpoch,
      };

  factory Recording.fromMap(Map<String, Object?> m) => Recording(
        id: m['id'] as String,
        title: m['title'] as String? ?? '',
        recordedAt: DateTime.fromMillisecondsSinceEpoch(m['recorded_at'] as int),
        durationMs: m['duration_ms'] as int? ?? 0,
        codec: m['codec'] as String,
        sampleRate: m['sample_rate'] as int,
        latitude: (m['latitude'] as num?)?.toDouble(),
        longitude: (m['longitude'] as num?)?.toDouble(),
        placeName: m['place_name'] as String?,
        dialectHint: m['dialect_hint'] as String?,
        status: RecStatus.values.byName(m['status'] as String),
        serverVersion: m['server_version'] as int? ?? 0,
        dirty: (m['dirty'] as int? ?? 0) == 1,
        metaSynced: (m['meta_synced'] as int? ?? 0) == 1,
        deleted: (m['deleted'] as int? ?? 0) == 1,
        hasConflict: (m['has_conflict'] as int? ?? 0) == 1,
        formattedText: m['formatted_text'] as String?,
        updatedAt: DateTime.fromMillisecondsSinceEpoch(m['updated_at'] as int),
      );

  String get displayTitle => title.isNotEmpty ? title : 'تسجيل ${recordedAt.toLocal().toString().substring(0, 16)}';
}

enum UploadState { pending, uploading, uploaded, failed }

class RecordingPart {
  RecordingPart({
    required this.id,
    required this.recordingId,
    required this.partIndex,
    required this.filePath,
    this.durationMs = 0,
    this.sizeBytes = 0,
    this.encPath,
    this.encSha256,
    this.wrappedKey,
    this.keyId,
    this.uploadUrl,
    this.uploadOffset = 0,
    this.uploadState = UploadState.pending,
    this.attempts = 0,
    this.lastError,
    this.audioOffloaded = false,
  });

  final String id;
  final String recordingId;
  final int partIndex;
  final String filePath;
  int durationMs;
  int sizeBytes;
  String? encPath;
  String? encSha256;
  String? wrappedKey;
  String? keyId;
  String? uploadUrl;
  int uploadOffset;
  UploadState uploadState;
  int attempts;
  String? lastError;
  bool audioOffloaded; // الصوت المحلي حُذف لتوفير المساحة بعد الرفع (النص باقٍ)

  Map<String, Object?> toMap() => {
        'id': id,
        'recording_id': recordingId,
        'part_index': partIndex,
        'file_path': filePath,
        'duration_ms': durationMs,
        'size_bytes': sizeBytes,
        'enc_path': encPath,
        'enc_sha256': encSha256,
        'wrapped_key': wrappedKey,
        'key_id': keyId,
        'upload_url': uploadUrl,
        'upload_offset': uploadOffset,
        'upload_state': uploadState.name,
        'attempts': attempts,
        'last_error': lastError,
        'audio_offloaded': audioOffloaded ? 1 : 0,
      };

  factory RecordingPart.fromMap(Map<String, Object?> m) => RecordingPart(
        id: m['id'] as String,
        recordingId: m['recording_id'] as String,
        partIndex: m['part_index'] as int,
        filePath: m['file_path'] as String,
        durationMs: m['duration_ms'] as int? ?? 0,
        sizeBytes: m['size_bytes'] as int? ?? 0,
        encPath: m['enc_path'] as String?,
        encSha256: m['enc_sha256'] as String?,
        wrappedKey: m['wrapped_key'] as String?,
        keyId: m['key_id'] as String?,
        uploadUrl: m['upload_url'] as String?,
        uploadOffset: m['upload_offset'] as int? ?? 0,
        uploadState: UploadState.values.byName(m['upload_state'] as String),
        attempts: m['attempts'] as int? ?? 0,
        lastError: m['last_error'] as String?,
        audioOffloaded: (m['audio_offloaded'] as int? ?? 0) == 1,
      );
}

class Segment {
  Segment({
    required this.segUid,
    required this.recordingId,
    required this.idx,
    required this.startMs,
    required this.endMs,
    required this.text,
    required this.baseText,
    required this.originalText,
    this.speaker,
    this.edited = false,
    this.conflictText,
  });

  final String segUid;
  final String recordingId;
  int idx;
  int startMs;
  int endMs;
  String? speaker;
  String text; // النص الحالي (قد يكون معدلاً محلياً)
  String baseText; // آخر نص متزامن مع الخادم (السلف المشترك للدمج الثلاثي)
  String originalText; // مخرج STT الحرفي
  bool edited;
  String? conflictText; // نسخة محلية متعارضة بانتظار قرار المستخدم

  bool get locallyChanged => text != baseText;

  Segment copyWith({String? text, String? baseText, String? conflictText, bool clearConflict = false}) => Segment(
        segUid: segUid,
        recordingId: recordingId,
        idx: idx,
        startMs: startMs,
        endMs: endMs,
        speaker: speaker,
        text: text ?? this.text,
        baseText: baseText ?? this.baseText,
        originalText: originalText,
        edited: edited,
        conflictText: clearConflict ? null : (conflictText ?? this.conflictText),
      );

  Map<String, Object?> toMap() => {
        'seg_uid': segUid,
        'recording_id': recordingId,
        'idx': idx,
        'start_ms': startMs,
        'end_ms': endMs,
        'speaker': speaker,
        'text': text,
        'base_text': baseText,
        'original_text': originalText,
        'edited': edited ? 1 : 0,
        'conflict_text': conflictText,
      };

  factory Segment.fromMap(Map<String, Object?> m) => Segment(
        segUid: m['seg_uid'] as String,
        recordingId: m['recording_id'] as String,
        idx: m['idx'] as int,
        startMs: m['start_ms'] as int,
        endMs: m['end_ms'] as int,
        speaker: m['speaker'] as String?,
        text: m['text'] as String,
        baseText: m['base_text'] as String,
        originalText: m['original_text'] as String,
        edited: (m['edited'] as int? ?? 0) == 1,
        conflictText: m['conflict_text'] as String?,
      );

  factory Segment.fromServer(String recordingId, Map<String, dynamic> j) => Segment(
        segUid: j['seg_uid'] as String,
        recordingId: recordingId,
        idx: j['idx'] as int,
        startMs: j['start_ms'] as int,
        endMs: j['end_ms'] as int,
        speaker: j['speaker'] as String?,
        text: j['text'] as String,
        baseText: j['text'] as String,
        originalText: j['original_text'] as String,
        edited: j['edited'] as bool? ?? false,
      );
}

class UploadLogEntry {
  UploadLogEntry({required this.event, required this.at, this.recordingId, this.partId, this.message = '', this.bytes});
  final String event; // upload_started|chunk_ok|upload_done|upload_failed|sync_conflict|pull|stt_status
  final DateTime at;
  final String? recordingId;
  final String? partId;
  final String message;
  final int? bytes;

  factory UploadLogEntry.fromMap(Map<String, Object?> m) => UploadLogEntry(
        event: m['event'] as String,
        at: DateTime.fromMillisecondsSinceEpoch(m['at'] as int),
        recordingId: m['recording_id'] as String?,
        partId: m['part_id'] as String?,
        message: m['message'] as String? ?? '',
        bytes: m['bytes'] as int?,
      );
}
