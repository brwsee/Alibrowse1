import 'dart:async';
import 'dart:io';
import 'package:just_audio/just_audio.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import '../../core/security/encryption_service.dart';
import '../../domain/models/knowledge_entry.dart';

/// خدمة تشغيل الصوت المشفر ومزامنة الطوابع الزمنية مع الفقرات النصية
class EncryptedAudioPlayerService {
  final AudioPlayer _player = AudioPlayer();
  final LocalEncryptionService _encryptionService;
  File? _tempDecryptedFile;

  EncryptedAudioPlayerService({
    required LocalEncryptionService encryptionService,
  }) : _encryptionService = encryptionService;

  Stream<Duration> get positionStream => _player.positionStream;
  Stream<PlayerState> get playerStateStream => _player.playerStateStream;
  bool get isPlaying => _player.playing;

  /// فك تشفير الملف الصوتي في ملف مؤقت معزول وتحميله في المشغل
  Future<Duration?> loadEncryptedEntry(KnowledgeEntry entry) async {
    await _cleanupTempFile();

    if (entry.localFilePath == null) {
      throw StateError('الملف الصوتي غير متوفر محلياً (تم إخلاؤه لتوفير المساحة).');
    }

    final encFile = File(entry.localFilePath!);
    if (!await encFile.exists()) {
      throw StateError('تعذر العثور على الملف الصوتي المشفر على الجهاز.');
    }

    final clearBytes = await _encryptionService.decryptAudioFile(
      encryptedFile: encFile,
      ivBase64: entry.encryptionIv,
    );

    final tempDir = await getTemporaryDirectory();
    final tempPath = p.join(
      tempDir.path,
      'play_${entry.id}.${entry.audioFormat}',
    );

    _tempDecryptedFile = File(tempPath);
    await _tempDecryptedFile!.writeAsBytes(clearBytes, flush: true);

    return _player.setFilePath(tempPath);
  }

  Future<void> play() => _player.play();
  Future<void> pause() => _player.pause();

  /// الانتقال الفوري إلى طابع زمني محدد عند النقر على الفقرة النصية
  Future<void> seekToMs(int milliseconds) async {
    await _player.seek(Duration(milliseconds: milliseconds));
    if (!_player.playing) {
      await _player.play();
    }
  }

  /// تحديد رقم الفقرة النشطة حالياً بناءً على موضع التشغيل بالمللي ثانية
  int? findActiveSegmentIndex(
    List<TranscriptSegment> segments,
    Duration position,
  ) {
    final posMs = position.inMilliseconds;
    for (var i = 0; i < segments.length; i++) {
      final seg = segments[i];
      if (posMs >= seg.startMs && posMs <= seg.endMs) {
        return i;
      }
    }
    return null;
  }

  Future<void> _cleanupTempFile() async {
    try {
      if (_tempDecryptedFile != null && await _tempDecryptedFile!.exists()) {
        await _tempDecryptedFile!.delete();
      }
    } catch (_) {
      // تجاهل أخطاء حذف الملف المؤقت
    } finally {
      _tempDecryptedFile = null;
    }
  }

  Future<void> dispose() async {
    await _player.stop();
    await _player.dispose();
    await _cleanupTempFile();
  }
}
