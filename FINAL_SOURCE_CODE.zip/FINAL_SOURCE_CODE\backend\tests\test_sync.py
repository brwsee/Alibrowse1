from conftest import encrypted_payload, register_recording, token_for, tus_metadata


def _transcribe(client, app, h, rec_id, part_id):
    blob, meta = encrypted_payload(app, b"\x00" * 5000)
    meta.update({"recording_id": rec_id, "part_id": part_id})
    r = client.post("/v1/uploads", headers={**h, "Upload-Length": str(len(blob)), "Upload-Metadata": tus_metadata(meta)})
    client.patch(r.headers["Location"], content=blob, headers={
        **h, "Upload-Offset": "0", "Content-Type": "application/offset+octet-stream"})


def test_optimistic_concurrency_conflict_between_devices(client, app):
    phone, tablet = token_for(client, "u1", "phone"), token_for(client, "u1", "tablet")
    rec_id, (part_id,) = register_recording(client, phone)
    _transcribe(client, app, phone, rec_id, part_id)
    rec = client.get(f"/v1/recordings/{rec_id}", headers=phone).json()
    v, seg0, seg1 = rec["version"], rec["segments"][0], rec["segments"][1]

    ok = client.put(f"/v1/recordings/{rec_id}/transcript", headers=phone, json={
        "base_version": v, "segments": [{"seg_uid": seg0["seg_uid"], "text": "السلام عليكم ورحمة الله."}]})
    assert ok.status_code == 200 and ok.json()["version"] == v + 1
    assert ok.json()["segments"][0]["edited"] is True

    # الجهاز الثاني يعدّل على نسخة قديمة => 409 مع نسخة الخادم للدمج
    conflict = client.put(f"/v1/recordings/{rec_id}/transcript", headers=tablet, json={
        "base_version": v, "segments": [{"seg_uid": seg1["seg_uid"], "text": "اليوم نتحدث عن المكتبة."}]})
    assert conflict.status_code == 409
    server = conflict.json()["detail"]["server"]
    assert server["version"] == v + 1 and server["last_editor_device"] == "phone"

    # بعد الدمج على العميل يعيد الإرسال بالنسخة الجديدة
    merged = client.put(f"/v1/recordings/{rec_id}/transcript", headers=tablet, json={
        "base_version": server["version"],
        "segments": [{"seg_uid": seg1["seg_uid"], "text": "اليوم نتحدث عن المكتبة."}]})
    assert merged.status_code == 200
    texts = [s["text"] for s in merged.json()["segments"]]
    assert texts[:2] == ["السلام عليكم ورحمة الله.", "اليوم نتحدث عن المكتبة."]
    assert "skl_sync_conflicts_total 1.0" in client.get("/metrics").text


def test_changes_feed_and_tombstones(client, app):
    h = token_for(client)
    a, _ = register_recording(client, h)
    b, _ = register_recording(client, h)
    feed = client.get("/v1/sync/changes", params={"since": 0, "limit": 1}, headers=h).json()
    assert feed["has_more"] is True and [r["id"] for r in feed["recordings"]] == [a]
    feed2 = client.get("/v1/sync/changes", params={"since": feed["cursor"]}, headers=h).json()
    assert [r["id"] for r in feed2["recordings"]] == [b]

    assert client.delete(f"/v1/recordings/{a}", headers=h).status_code == 204
    feed3 = client.get("/v1/sync/changes", params={"since": feed2["cursor"]}, headers=h).json()
    assert feed3["recordings"][0]["id"] == a and feed3["recordings"][0]["deleted"] is True
    assert feed3["recordings"][0]["latitude"] is None  # بيانات الموقع تُمسح مع الحذف


def test_other_user_cannot_see_changes(client, app):
    register_recording(client, token_for(client, "u1"))
    feed = client.get("/v1/sync/changes", headers=token_for(client, "u2")).json()
    assert feed["recordings"] == []


def test_requires_auth(client):
    assert client.get("/v1/sync/changes").status_code == 401
    assert client.get("/v1/sync/changes", headers={"Authorization": "Bearer nope"}).status_code == 401
