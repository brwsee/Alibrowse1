"""مقيّم جودة التفريغ العربي (يُشغَّل يدوياً أو في CI ليلياً).

المدخل: ملف JSONL، كل سطر:
  {"audio": "clips/eg_001.wav", "reference": "النص المرجعي", "dialect": "ar-EG", "domain": "lecture"}

المخرجات: تقرير JSON + Markdown بـ WER/CER لكل لهجة ومجال، وزمن المعالجة وRTF،
ومقارنة قبل/بعد التحسين اللغوي. يُرجع رمز خروج 1 إذا تجاوزت أي لهجة العتبة (بوابة جودة).

الاستخدام:
  python -m quality.eval_stt --manifest quality/dataset/manifest.jsonl --out reports/ \
      --max-wer ar-EG=0.18 --max-wer ar-SA=0.20 --max-wer default=0.25
"""
from __future__ import annotations

import argparse
import json
import statistics
import sys
import time
import wave
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.quality import cer, wer  # noqa: E402
from app.segmenter import segment_words  # noqa: E402

_DIALECT_LANG = {"ar-EG": ["ar-EG"]}


def audio_seconds(path: Path) -> float | None:
    try:
        with wave.open(str(path)) as w:
            return w.getnframes() / float(w.getframerate())
    except (wave.Error, EOFError):
        return None


def build_provider(name: str):
    if name == "fake":
        from app.stt.fake_provider import FakeRefiner, FakeSttProvider
        return FakeSttProvider(), FakeRefiner()
    from app.stt.gemini_provider import GeminiRefiner, GeminiSttProvider
    return GeminiSttProvider(smart_pass=False), GeminiRefiner()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True, type=Path)
    ap.add_argument("--out", default=Path("reports"), type=Path)
    ap.add_argument("--provider", default="gemini")
    ap.add_argument("--no-refine", action="store_true")
    ap.add_argument("--max-wer", action="append", default=[], help="dialect=threshold, e.g. ar-EG=0.18")
    args = ap.parse_args()

    thresholds = {k: float(v) for k, v in (t.split("=") for t in args.max_wer)}
    provider, refiner = build_provider(args.provider)
    base = args.manifest.parent
    rows = []
    for line in args.manifest.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        item = json.loads(line)
        audio = (base / item["audio"]).resolve()
        dialect = item.get("dialect", "ar")
        t0 = time.monotonic()
        result = provider.transcribe(audio, language_codes=_DIALECT_LANG.get(dialect, []), diarize=False)
        paragraphs = segment_words(result.words)
        raw_hyp = " ".join(p.text for p in paragraphs) or result.text
        refined_hyp = raw_hyp
        if refiner and not args.no_refine and paragraphs:
            out = refiner.refine([p.text for p in paragraphs])
            if out:
                refined_hyp = " ".join(out)
        elapsed = time.monotonic() - t0
        secs = audio_seconds(audio)
        ref = item["reference"]
        rows.append({
            "audio": item["audio"], "dialect": dialect, "domain": item.get("domain", "general"),
            "wer_raw": wer(ref, raw_hyp).rate, "wer": wer(ref, refined_hyp).rate,
            "cer": cer(ref, refined_hyp).rate, "latency_s": round(elapsed, 2),
            "rtf": round(elapsed / secs, 3) if secs else None, "hypothesis": refined_hyp,
        })
        print(f"[{dialect}] {item['audio']}: WER={rows[-1]['wer']:.3f} CER={rows[-1]['cer']:.3f}", flush=True)

    by_dialect: dict[str, list[dict]] = defaultdict(list)
    for r in rows:
        by_dialect[r["dialect"]].append(r)
    summary, failed = {}, []
    for d, items in sorted(by_dialect.items()):
        s = {
            "n": len(items),
            "wer_raw": statistics.mean(i["wer_raw"] for i in items),
            "wer": statistics.mean(i["wer"] for i in items),
            "cer": statistics.mean(i["cer"] for i in items),
            "p95_latency_s": sorted(i["latency_s"] for i in items)[max(0, int(len(items) * 0.95) - 1)],
        }
        limit = thresholds.get(d, thresholds.get("default"))
        s["threshold"], s["pass"] = limit, (limit is None or s["wer"] <= limit)
        if not s["pass"]:
            failed.append(d)
        summary[d] = s

    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "stt_eval.json").write_text(
        json.dumps({"summary": summary, "items": rows}, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    md = ["| اللهجة | العينات | WER خام | WER بعد التحسين | CER | p95 زمن (ث) | العتبة | النتيجة |", "|---|---|---|---|---|---|---|---|"]
    for d, s in summary.items():
        md.append(f"| {d} | {s['n']} | {s['wer_raw']:.3f} | {s['wer']:.3f} | {s['cer']:.3f} | {s['p95_latency_s']} | "
                  f"{s['threshold'] if s['threshold'] is not None else '-'} | {'✅' if s['pass'] else '❌'} |")
    (args.out / "stt_eval.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    print("\n".join(md))
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
