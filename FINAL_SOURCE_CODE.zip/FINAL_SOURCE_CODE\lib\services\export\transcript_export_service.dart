import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import '../../domain/models/knowledge_entry.dart';

/// صيغ التصدير المتاحة للكيان المعرفي
enum TranscriptExportFormat {
  markdown('md', 'مستند منسق (Markdown)'),
  srt('srt', 'ملف ترجمة وطوابع زمنية (SRT)'),
  txt('txt', 'نص صافي مع الميتا (TXT)');

  final String extension;
  final String arabicLabel;
  const TranscriptExportFormat(this.extension, this.arabicLabel);
}

/// خدمة تصدير التسجيلات المعرفية وتفريغاتها النصية
class TranscriptExportService {
  /// توليد محتوى النص وفق الصيغة المختارة
  String formatEntry(KnowledgeEntry entry, TranscriptExportFormat format) {
    switch (format) {
      case TranscriptExportFormat.markdown:
        return _buildMarkdown(entry);
      case TranscriptExportFormat.srt:
        return _buildSrt(entry);
      case TranscriptExportFormat.txt:
        return _buildPlainText(entry);
    }
  }

  /// حفظ الملف المصدّر في مجلد المستندات وإرجاع مساره الكامل
  Future<File> exportEntryToFile(
    KnowledgeEntry entry,
    TranscriptExportFormat format,
  ) async {
    final content = formatEntry(entry, format);
    final docsDir = await getApplicationDocumentsDirectory();
    final exportsDir = Directory(p.join(docsDir.path, 'exports'));
    if (!await exportsDir.exists()) {
      await exportsDir.create(recursive: true);
    }

    final safeId = entry.id.substring(0, 8);
    final fileName = 'knowledge_${safeId}.${format.extension}';
    final outFile = File(p.join(exportsDir.path, fileName));
    await outFile.writeAsString(content, flush: true);
    return outFile;
  }

  String _buildMarkdown(KnowledgeEntry entry) {
    final buffer = StringBuffer()
      ..writeln('# ${entry.title}')
      ..writeln()
      ..writeln('- **تاريخ التسجيل:** ${entry.recordedAt.toIso8601String()}')
      ..writeln('- **المدة:** ${entry.durationMs ~/ 1000} ثانية (الحد الأقصى 120 ثانية)')
      ..writeln('- **اللهجة العربية:** ${entry.dialectHint.label}')
      ..writeln('- **حالة المزامنة:** ${entry.syncStatus.arabicLabel}')
      ..writeln('- **بصمة التشفير (SHA-256):** `${entry.fileSha256}`');

    if (entry.placeName != null || entry.latitude != null) {
      buffer.writeln(
        '- **الموقع الجغرافي:** ${entry.placeName ?? ""} (${entry.latitude ?? ""}, ${entry.longitude ?? ""})',
      );
    }

    buffer
      ..writeln()
      ..writeln('---')
      ..writeln()
      ..writeln('## التفريغ النصي المنسق بالطوابع الزمنية')
      ..writeln();

    for (final seg in entry.segments) {
      buffer.writeln(
        '- **`[${seg.formattedStartTime}]`** ${seg.editedText.trim()}',
      );
    }

    return buffer.toString();
  }

  String _buildSrt(KnowledgeEntry entry) {
    final buffer = StringBuffer();
    for (var i = 0; i < entry.segments.length; i++) {
      final seg = entry.segments[i];
      buffer
        ..writeln('${i + 1}')
        ..writeln('${_msToSrtTime(seg.startMs)} --> ${_msToSrtTime(seg.endMs)}')
        ..writeln(seg.editedText.trim())
        ..writeln();
    }
    return buffer.toString();
  }

  String _buildPlainText(KnowledgeEntry entry) {
    return '${entry.title}\n'
        'التاريخ: ${entry.recordedAt}\n'
        'المدة: ${entry.durationMs ~/ 1000} ثانية\n'
        '----------------------------------------\n'
        '${entry.fullTranscriptWithTimestamps}\n';
  }

  String _msToSrtTime(int ms) {
    final hours = (ms ~/ 3600000).toString().padLeft(2, '0');
    final minutes = ((ms % 3600000) ~/ 60000).toString().padLeft(2, '0');
    final seconds = ((ms % 60000) ~/ 1000).toString().padLeft(2, '0');
    final millis = (ms % 1000).toString().padLeft(3, '0');
    return '$hours:$minutes:$seconds,$millis';
  }
}
