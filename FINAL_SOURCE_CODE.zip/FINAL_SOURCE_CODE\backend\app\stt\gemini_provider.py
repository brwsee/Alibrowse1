"""مزود Gemini للتفريغ: gemini-3.5-transcribe (كلمات + طوابع زمنية + فصل متحدثين)
ثم تحسين نحوي/ترقيمي اختياري لكل فقرة عبر gemini-3.8-flash مع مخرجات JSON مقيدة.

الخصوصية: store=False في كل الطلبات، وحذف الملف من Files API فور الانتهاء.
"""
from __future__ import annotations

import json
import logging
import re
from pathlib import Path

from .base import SttResult, Word

log = logging.getLogger("skl.stt.gemini")

_OFFSET = re.compile(r"^\s*([\d.]+)s\s*$")

REFINE_SYSTEM = (
    "أنت مدقق لغوي للنصوص العربية المفرّغة آلياً من الكلام. "
    "مهمتك لكل فقرة: إضافة علامات الترقيم العربية (، . ؟ ! ؛) وتصحيح الأخطاء الإملائية والنحوية الواضحة "
    "وإزالة كلمات الحشو (مثل: اممم، آه) فقط. "
    "ممنوع منعاً باتاً: إضافة معلومات، حذف محتوى ذي معنى، إعادة الصياغة، ترجمة اللهجة إلى الفصحى، "
    "أو دمج/تقسيم الفقرات. حافظ على اللهجة والمفردات العامية كما هي. "
    "أعد نفس عدد الفقرات وبنفس الترتيب."
)


def parse_offset_ms(value: str | None) -> int | None:
    if not value:
        return None
    m = _OFFSET.match(str(value))
    return int(round(float(m.group(1)) * 1000)) if m else None


def extract_words(response) -> list[Word]:  # noqa: ANN001
    words: list[Word] = []
    for step in getattr(response, "steps", None) or []:
        for content in getattr(step, "content", None) or []:
            for ann in getattr(content, "annotations", None) or []:
                if getattr(ann, "type", None) != "word_info":
                    continue
                start = parse_offset_ms(getattr(ann, "start_offset", None))
                end = parse_offset_ms(getattr(ann, "end_offset", None))
                if start is None or end is None:
                    continue
                words.append(Word(text=ann.text, start_ms=start, end_ms=end, speaker=getattr(ann, "speaker", None)))
    return words


class GeminiSttProvider:
    name = "gemini-3.5-transcribe"

    def __init__(self, model: str = "gemini-3.5-transcribe", smart_pass: bool = True):
        from google import genai  # import متأخر كي تعمل الاختبارات دون SDK/مفتاح

        self._client = genai.Client()  # يقرأ GEMINI_API_KEY من البيئة
        self._model = model
        self._smart_pass = smart_pass

    def transcribe(self, audio_path: Path, *, language_codes: list[str], diarize: bool) -> SttResult:
        audio_file = self._client.files.upload(file=str(audio_path))
        try:
            mode: dict = {"type": "verbatim", "timestamp_granularities": ["word"]}
            if diarize:
                mode["diarization_mode"] = "speaker"
            verbatim = self._client.interactions.create(
                model=self._model,
                input=[audio_file],
                store=False,
                generation_config={"transcription_config": {"language_codes": language_codes, "mode": mode}},
            )
            words = extract_words(verbatim)
            formatted = None
            if self._smart_pass:
                # نسخة "ذكية" منسقة للنص الكامل (إزالة التردد + فقرات + ترقيم) تُعرض كبديل للقراءة
                smart = self._client.interactions.create(
                    model=self._model,
                    input=[audio_file],
                    store=False,
                    generation_config={
                        "transcription_config": {"language_codes": language_codes, "mode": {"type": "smart"}}
                    },
                )
                formatted = smart.output_text
            return SttResult(words=words, text=verbatim.output_text or "", provider=self.name, formatted_text=formatted)
        finally:
            try:
                self._client.files.delete(name=audio_file.name)
            except Exception:  # noqa: BLE001
                log.warning("failed to delete uploaded file from Gemini Files API", exc_info=True)


class GeminiRefiner:
    """تحسين نحوي لكل فقرة مع الحفاظ على التوافق 1:1 مع الطوابع الزمنية."""

    def __init__(self, model: str = "gemini-3.8-flash"):
        from google import genai

        self._client = genai.Client()
        self._model = model

    def refine(self, paragraphs: list[str]) -> list[str] | None:
        if not paragraphs:
            return paragraphs
        payload = json.dumps({"paragraphs": paragraphs}, ensure_ascii=False)
        interaction = self._client.interactions.create(
            model=self._model,
            system_instruction=REFINE_SYSTEM,
            input=payload,
            store=False,
            response_format={
                "type": "text",
                "mime_type": "application/json",
                "schema": {
                    "type": "object",
                    "properties": {"paragraphs": {"type": "array", "items": {"type": "string"}}},
                    "required": ["paragraphs"],
                },
            },
        )
        try:
            out = json.loads(interaction.output_text or "{}").get("paragraphs")
        except json.JSONDecodeError:
            return None
        if not isinstance(out, list) or len(out) != len(paragraphs):
            return None
        return [str(p) for p in out]
