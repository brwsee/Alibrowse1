# 🎙️ المكتبة المعرفية الذكية (`Smart Knowledge Library`) — نسخة التسليم النهائية (`v6.0`)

تطبيق متكامل **يعمل بدون إنترنت أولاً (`Offline-First`)** لتسجيل الملاحظات الصوتية القصيرة (**بحد أقصى صارم دقيقتين / 120 ثانية**)، حفظها محلياً مع **التاريخ والوقت**، وتفريغها صوتياً إلى نص عربي مكتوب تلقائياً فور الاتصال بالإنترنت باستخدام **Google Gemini API**، مع عرض التفريغ في **خانة واحدة موحدة تحت عنوان «التفريغ الصوتي»**، ومحرك بحث عربي ذكي وفوري.

---

## 📌 1. ملخص المزايا والوظائف المعتمدة في هذه النسخة

1. **التسجيل الصوتي المقيد بدقيقتين (`120 ثانية`)**:
   - عداد تنازلي وتنبيه بصري عند الثانية `105`، وإيقاف وحفظ تلقائي عند الثانية `120`.
   - تسجيل فعلي عبر الميكروفون (`MediaRecorder` في الويب و `record` في Flutter) بصيغة مضغوطة عالية الكفاءة (`Opus 32kbps @ 16kHz Mono` / `WebM` / `MP4`).
2. **دعم العمل الكامل بدون إنترنت (`Offline-First PWA & Mobile`)**:
   - زر **«تثبيت صلاحية الميكروفون والعمل بدون إنترنت»** لمنح الإذن لمرة واحدة.
   - تخزين التطبيق بالكامل على الهاتف/المتصفح عبر `Service Worker (sw.js)` و `manifest.json`.
   - حفظ المقطع الصوتي المسجل أثناء انقطاع الشبكة داخل التخزين المحلي (`localStorage` / `SQLite + AES-256-GCM`) بحالة `needsTranscription: true`.
3. **التفريغ الصوتي التلقائي فور الاتصال بالإنترنت**:
   - مراقب شبكة ذكي يعمل عبر:
     - حدث عودة الإنترنت (`window.addEventListener('online')`).
     - حدث فتح التطبيق أو العودة لشاشته (`visibilitychange` و `DOMContentLoaded`).
     - فاحص خلفي دوري كل `6 ثوانٍ` يكتشف أي مقطع مسجل بدون إنترنت ويحوله تلقائياً إلى نص عربي عبر **Gemini API** (`gemini-3.8-flash` ثم `gemini-3.5-flash-lite` ثم `gemini-2.5-flash` ثم `gemini-2.0-flash`).
   - معالجة تلقائية لصيغ الصوت في جميع المتصفحات (بما فيها Firefox و Safari و Chrome عبر تنظيف `mime_type` من `;codecs=opus`).
4. **واجهة بطاقة التسجيل النظيفة والموحدة**:
   - خالية تماماً من أي تسجيلات وهمية أو مربعات فارغة.
   - عرض **📅 التاريخ** و **⏰ الوقت** تلقائياً لكل مقطع صوتي.
   - عرض النص المحول في **خانة واحدة موحدة** تحت عنوان **`📝 التفريغ الصوتي`** بدون طوابع زمنية مجزأة (`[00:04]`) أو عناوين مكررة (`cleanTranscriptText`).
   - إمكانية تعديل النص يدوياً، أو إعادة التفريغ عبر زر **«🔄 تفريغ النص الآن»**، أو الاستماع للتسجيل، أو حذفه.

---

## 📂 2. هيكلية ملفات المشروع الكاملة (`FINAL_SOURCE_CODE`)

```text
FINAL_SOURCE_CODE/
├── index.html                        # تطبيق الويب والموبايل التفاعلي الكامل (PWA) - الملف الرئيسي المنشور على Vercel
├── web_preview/
│   └── index.html                    # نسخة معاينة مطابقة تماماً لـ index.html
├── manifest.json                     # إعدادات تثبيت التطبيق على شاشة الهاتف (PWA Manifest)
├── sw.js                             # Service Worker لتشغيل التطبيق بدون إنترنت (Offline Caching)
├── package.json                      # إعدادات تشغيل ونشر تطبيق الويب (Node / Vercel CLI)
├── vercel.json                       # إعدادات النشر على منصة Vercel
├── railway.json                      # إعدادات نشر الخادم السحابي على منصة Railway
├── .env.example                      # نموذج متغيرات البيئة (بدون أي مفاتيح سرية)
├── README.md                         # هذا الدليل الشامل للمشروع
│
├── database/
│   └── schema.sql                    # مخطط قاعدة البيانات المحلية (SQLite + FTS5 + Upload Queue + Custom Vocab)
│
├── lib/                              # الكود المصدري لتطبيق الموبايل الأصلي (Flutter - Android & iOS)
│   ├── main.dart                     # نقطة الدخول وواجهة المستخدم العربية (RTL)
│   ├── core/
│   │   ├── constants/app_constants.dart          # الثوابت الهندسية (حد الـ 120 ثانية، Opus 32kbps، TUS)
│   │   ├── security/encryption_service.dart      # تشفير الملفات الصوتية AES-256-GCM ومفاتيح SQLCipher
│   │   ├── sync/hlc_clock.dart                   # الساعة المنطقية الهجينة (HLC) لمنع تعارض المزامنة
│   │   ├── sync/conflict_resolver.dart           # خوارزمية دمج التعديلات بين الأجهزة
│   │   ├── utils/arabic_text_evaluator.dart      # تطبيع النص العربي وحساب دقة التفريغ (Normalized WER)
│   │   ├── benchmark/golden_arabic_dataset.dart  # مجموعة الاختبار القياسية للهجات العربية الـ 5
│   │   └── logging/app_logger_service.dart       # نظام السجلات الدائري (Rotating JSONL Logger)
│   ├── domain/
│   │   └── models/knowledge_entry.dart           # نماذج البيانات (KnowledgeEntry, TranscriptSegment, SyncStatus)
│   ├── data/
│   │   └── local/local_database.dart             # قاعدة البيانات المشفرة SQLCipher + محرك البحث FTS5
│   ├── services/
│   │   ├── audio/audio_recorder_service.dart          # مسجل الصوت مع الإيقاف التلقائي عند 120 ثانية
│   │   ├── audio/encrypted_audio_player_service.dart  # مشغل الصوت المشفر في الذاكرة
│   │   ├── stt/on_device_draft_stt_service.dart       # التفريغ المبدئي المحلي والقاموس الشخصي
│   │   ├── sync/sync_upload_service.dart              # الرفع المتقطع القابل للاستئناف (TUS 256KB Chunks)
│   │   ├── sync/background_sync_worker.dart           # عامل المزامنة الخلفي (WorkManager)
│   │   ├── storage/storage_quota_service.dart         # الإدارة الذكية لمساحة التخزين المحلي
│   │   └── export/transcript_export_service.dart      # تصدير النصوص بصيغ Markdown و SRT و TXT
│   └── presentation/
│       └── screens/settings_and_diagnostics_screen.dart # شاشة الإعدادات والقاموس وتشخيص الأخطاء
│
├── mobile/                           # وحدات إضافية مساعدة للموبايل
├── test/
│   └── arabic_evaluator_and_limits_test.dart     # اختبارات الوحدة لتطبيق Flutter
│
├── backend/                          # الخادم السحابي الخلفي (Python FastAPI + Gemini API + TUS)
│   ├── main.py                       # خادم FastAPI الرئيسي للتفريغ الصوتي والرفع المتقطع TUS
│   ├── requirements.txt              # قائمة مكتبات بايثون وإصداراتها الدقيقة
│   ├── Dockerfile                    # حاوية Docker لتشغيل الخادم على أي خدمة سحابية
│   ├── app/                          # حزمة الخادم المتقدمة (auth, crypto, db, pipeline, routes, stt)
│   ├── quality/                      # أدوات قياس جودة التفريغ العربي (WER/CER)
│   └── tests/                        # اختبارات الخادم السحابي (Pytest)
│
├── .vscode/                          # إعدادات التشغيل والتصحيح الجاهزة لبرنامج VS Code
│   ├── launch.json
│   └── extensions.json
└── .github/workflows/                # بناء أوتوماتيكي لملف الـ APK عبر GitHub Actions
    └── build_and_release.yml
```

---

## 📦 3. جدول المكتبات والاعتماديات وإصداراتها (`Dependencies & Versions`)

### أ) تطبيق الويب التفاعلي (`index.html` / `package.json`)
- **الاعتماديات وقت التشغيل (Runtime):** `Zero Dependencies` (يعمل بـ HTML5 + CSS3 + Vanilla JavaScript ES2022 + Web Audio / MediaRecorder API + Web Speech API + LocalStorage + Service Worker بدون الحاجة لأي مكتبة خارجية).
- **أدوات التطوير والنشر الاختيارية (`package.json`):**
  - `serve`: `^14.2.3`
  - `vercel`: `^37.0.0`

### ب) تطبيق الموبايل (`pubspec.yaml` — Flutter SDK `>=3.3.0 <4.0.0`)
| المكتبة | الإصدار | الوظيفة |
|---|---|---|
| `flutter_riverpod` | `^2.5.1` | إدارة الحالة وحقن الاعتماديات |
| `sqflite_sqlcipher` | `^3.1.0+1` | قاعدة بيانات SQLite مشفرة مع دعم البحث العربي `FTS5` |
| `path_provider` | `^2.1.3` | الوصول لمجلدات التخزين الآمنة في الهاتف |
| `path` | `^1.9.0` | إدارة مسارات الملفات |
| `record` | `^5.1.2` | التسجيل الصوتي المضغوط بحد 120 ثانية |
| `just_audio` | `^0.9.38` | تشغيل المقاطع الصوتية |
| `flutter_secure_storage` | `^9.2.2` | حفظ مفاتيح التشفير في Android Keystore / iOS Keychain |
| `cryptography` | `^2.7.0` | تشفير الملفات الصوتية بمعيار `AES-256-GCM` |
| `crypto` | `^3.0.3` | حساب البصمات الرقمية `SHA-256` |
| `dio` | `^5.4.3+1` | عميل HTTP للرفع المتقطع عبر بروتوكول `TUS` |
| `connectivity_plus` | `^6.0.3` | مراقبة حالة الاتصال بالإنترنت |
| `workmanager` | `^0.5.2` | المزامنة والتفريغ التلقائي في الخلفية |
| `uuid` | `^4.4.0` | توليد المعرفات الفريدة `UUID v4` |
| `intl` | `^0.19.0` | تنسيق التاريخ والوقت باللغة العربية |
| `flutter_lints` *(dev)* | `^4.0.0` | فحص جودة الكود |
| `sqflite_common_ffi` *(dev)* | `^2.3.3` | تشغيل اختبارات قاعدة البيانات على سطح المكتب |

### ج) الخادم السحابي (`backend/requirements.txt` — Python `>=3.11`)
| المكتبة | الإصدار | الوظيفة |
|---|---|---|
| `fastapi` | `0.111.0` | إطار عمل واجهة البرمجة السحابية (REST & TUS) |
| `uvicorn[standard]` | `0.30.1` | خادم ASGI عالي الأداء |
| `pydantic` | `2.7.4` | التحقق من صحة البيانات والمخططات |
| `google-genai` | `>=2.30.1` | حزمة Google Gemini الرسمية للتفريغ الصوتي |
| `python-multipart` | `0.0.9` | استقبال الملفات الصوتية المرفوعة |
| `cryptography` | `42.0.8` | فك تشفير الملفات والتحقق الأمني |
| `PyJWT` | `2.8.0` | مصادقة الجلسات عبر رموز JWT |
| `httpx` | `0.27.0` | عميل اختبار الطلبات غير المتزامنة |
| `pytest` | `8.2.2` | إطار تشغيل الاختبارات الآلية |

---

## 🗄️ 4. قواعد البيانات والخدمات الخارجية وكيفية إعادة ربطها

### أولاً: قواعد البيانات المحلية (Local Databases)
1. **في تطبيق الويب (`index.html`)**:
   - يستخدم التخزين المحلي الدائم في المتصفح (`localStorage`) تحت المفاتيح:
     - `skl_entries_v6`: يحفظ مصفوفة التسجيلات (العنوان، التاريخ، الوقت، النص المفرغ، حالة التفريغ `needsTranscription`، والملف الصوتي بصيغة `audioDataUrl` Base64).
     - `skl_gemini_api_key`: يحفظ مفتاح Gemini API محلياً في جهاز المستخدم فقط.
     - `skl_mic_granted`: يحفظ حالة منح صلاحية الميكروفون.
   - **لا يحتاج إلى أي إعداد خارجي**؛ يتم إنشاؤه تلقائياً بمجرد فتح الصفحة.
2. **في تطبيق Flutter (`lib/data/local/local_database.dart` و `database/schema.sql`)**:
   - يستخدم قاعدة بيانات `SQLite` مشفرة عبر `SQLCipher` باسم `smart_knowledge_vault.db` مع جدول البحث النصي الفوري `FTS5 (knowledge_fts)`.
   - يتم إنشاء الجداول تلقائياً عند أول تشغيل للتطبيق، كما يتوفر المخطط الكامل في ملف [`database/schema.sql`](database/schema.sql).
3. **في الخادم السحابي (`backend/app/db.py`)**:
   - يستخدم قاعدة بيانات `SQLite` محلية في المسار المحدد بمتغير `SKL_DATABASE_URL` (افتراضياً `sqlite:///./data/skl.db`).

### ثانياً: الخدمات الخارجية وكيفية إعادة ربطها
1. **خدمة Google Gemini API (للتفريغ الصوتي التلقائي)**:
   - **كيف تحصل على المفتاح؟** من منصة [Google AI Studio](https://aistudio.google.com/apikey) مجاناً.
   - **كيفية ربطها في تطبيق الويب (`index.html`)**: الصق المفتاح في خانة **«مفتاح Gemini API المجاني»** أعلى التطبيق واضغط **«حفظ المفتاح»**.
   - **كيفية ربطها في الخادم السحابي (`backend/`)**: انسخ ملف `.env.example` إلى `.env` وضع المفتاح أمام `GEMINI_API_KEY=`.
2. **منصة الاستضافة السحابية للواجهة (Vercel)**:
   - المشروع يحتوي على ملف `vercel.json` جاهز.
   - لإعادة ربطه بحساب جديد في Vercel: ادخل إلى [vercel.com/new](https://vercel.com/new) وارفع مجلد `FINAL_SOURCE_CODE` مباشرة (أو شغّل `npx vercel --prod`).
3. **منصة استضافة الخادم الخلفي (Railway أو Docker)**:
   - المشروع يحتوي على `railway.json` و `backend/Dockerfile`.
   - لإعادة ربطه: ارفع المجلد إلى Railway أو شغّل الحاوية عبر `docker build -t skl-backend ./backend` مع تمرير متغير البيئة `GEMINI_API_KEY`.

---

## 🚀 5. طريقة التثبيت والتشغيل والتطوير

### 1) تشغيل تطبيق الويب (PWA) مباشرة
- افتح الملف [`index.html`](index.html) بأي متصفح حديث، أو شغّل خادماً محلياً عبر:
  ```bash
  npx serve . -l 3000
  ```

### 2) تشغيل الخادم السحابي واختباراته (`FastAPI Backend`)
```bash
# 1. إعداد ملف البيئة
cp .env.example .env

# 2. تثبيت المكتبات
pip install -r backend/requirements.txt

# 3. تشغيل الاختبارات الآلية
pytest backend/tests

# 4. تشغيل الخادم
uvicorn backend.main:app --reload --port 8000
```

### 3) تشغيل تطبيق الموبايل واختباراته (`Flutter`)
```bash
# 1. جلب الحزم
flutter pub get

# 2. تشغيل اختبارات الوحدة
flutter test

# 3. تشغيل التطبيق على الهاتف أو المحاكي
flutter run
```

---

## 🤖 6. كيفية مواصلة التطوير باستخدام ChatGPT أو Gemini أو VS Code

- **في VS Code**: افتح مجلد `FINAL_SOURCE_CODE` مباشرة؛ ستجد إعدادات التشغيل الجاهزة في `.vscode/launch.json`.
- **مع ChatGPT أو Gemini**:
  - لتعديل تطبيق الويب المنشور على Vercel: ارفع ملف `index.html` فقط واطلب التعديل الذي تريده.
  - لتعديل تطبيق Flutter أو الخادم: ارفع ملف `README.md` مع الملف المراد تعديله من `lib/` أو `backend/`.
