from __future__ import annotations

from prometheus_client import CollectorRegistry, Counter, Histogram


class Metrics:
    """مؤشرات أداء تُعرض على /metrics بصيغة Prometheus."""

    def __init__(self) -> None:
        self.registry = CollectorRegistry()
        r = self.registry
        self.upload_bytes = Counter("skl_upload_bytes_total", "Bytes received via resumable upload", registry=r)
        self.uploads = Counter("skl_uploads_total", "Upload outcomes", ["outcome"], registry=r)
        self.stt_jobs = Counter("skl_stt_jobs_total", "Transcription job outcomes", ["outcome"], registry=r)
        self.stt_latency = Histogram(
            "skl_stt_latency_seconds", "End-to-end transcription latency per part",
            buckets=(1, 2, 5, 10, 20, 40, 80, 160, 320, 640), registry=r,
        )
        self.stt_rtf = Histogram(
            "skl_stt_real_time_factor", "Processing time / audio duration",
            buckets=(0.05, 0.1, 0.2, 0.3, 0.5, 0.75, 1, 1.5, 2, 4), registry=r,
        )
        self.refine = Counter("skl_refine_total", "LLM refinement per paragraph", ["outcome"], registry=r)
        self.sync_conflicts = Counter("skl_sync_conflicts_total", "Optimistic concurrency conflicts", registry=r)
