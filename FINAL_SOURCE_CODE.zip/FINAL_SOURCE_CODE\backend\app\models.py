from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import (
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
    select,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, relationship


def utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Base(DeclarativeBase):
    pass


class Recording(Base):
    """الكيان الموحد: تسجيل + بيانات ميتا + تفريغ (عبر segments)."""

    __tablename__ = "recordings"

    id: Mapped[str] = mapped_column(String(36), primary_key=True)  # UUID من العميل
    owner_id: Mapped[str] = mapped_column(String(64), index=True)
    title: Mapped[str] = mapped_column(String(300), default="")
    recorded_at: Mapped[datetime] = mapped_column(DateTime)
    duration_ms: Mapped[int] = mapped_column(Integer, default=0)
    codec: Mapped[str] = mapped_column(String(16), default="wav")
    sample_rate: Mapped[int] = mapped_column(Integer, default=16000)
    latitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    longitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    place_name: Mapped[str | None] = mapped_column(String(200), nullable=True)
    dialect_hint: Mapped[str | None] = mapped_column(String(16), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="pending")
    # pending -> uploading -> queued -> transcribing -> transcribed | failed
    version: Mapped[int] = mapped_column(Integer, default=1)  # optimistic concurrency
    change_seq: Mapped[int] = mapped_column(Integer, default=0, index=True)  # sync cursor
    deleted: Mapped[bool] = mapped_column(Boolean, default=False)
    formatted_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    last_editor_device: Mapped[str | None] = mapped_column(String(64), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)

    parts: Mapped[list["RecordingPart"]] = relationship(
        back_populates="recording", order_by="RecordingPart.part_index", cascade="all, delete-orphan"
    )
    segments: Mapped[list["Segment"]] = relationship(
        back_populates="recording", order_by="Segment.idx", cascade="all, delete-orphan"
    )


class RecordingPart(Base):
    """كل استئناف للتسجيل يُنتج جزءاً مستقلاً؛ يُرفع ويُفرَّغ منفصلاً ثم تُدمج الطوابع الزمنية."""

    __tablename__ = "recording_parts"
    __table_args__ = (UniqueConstraint("recording_id", "part_index"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    recording_id: Mapped[str] = mapped_column(ForeignKey("recordings.id"), index=True)
    part_index: Mapped[int] = mapped_column(Integer)
    duration_ms: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(20), default="pending")  # pending|uploaded|transcribed|failed
    upload_id: Mapped[str | None] = mapped_column(String(36), nullable=True)

    recording: Mapped[Recording] = relationship(back_populates="parts")


class Upload(Base):
    __tablename__ = "uploads"

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    owner_id: Mapped[str] = mapped_column(String(64), index=True)
    recording_id: Mapped[str] = mapped_column(String(36), index=True)
    part_id: Mapped[str] = mapped_column(String(36), index=True)
    length: Mapped[int] = mapped_column(Integer)
    offset: Mapped[int] = mapped_column(Integer, default=0)
    sha256: Mapped[str] = mapped_column(String(64))  # hex digest of the full ciphertext
    key_id: Mapped[str] = mapped_column(String(64))
    wrapped_key: Mapped[str] = mapped_column(Text)  # base64 RSA-OAEP(DEK)
    codec: Mapped[str] = mapped_column(String(16))
    status: Mapped[str] = mapped_column(String(20), default="in_progress")  # in_progress|complete|failed
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)
    expires_at: Mapped[datetime] = mapped_column(DateTime)


class Segment(Base):
    """فقرة مفرغة بطابع زمني؛ تحتفظ بالنص الأصلي من STT للمقارنة وقياس جودة التعديلات."""

    __tablename__ = "segments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    recording_id: Mapped[str] = mapped_column(ForeignKey("recordings.id"), index=True)
    seg_uid: Mapped[str] = mapped_column(String(36))  # ثابت عبر الأجهزة لدمج التعارضات
    part_index: Mapped[int] = mapped_column(Integer, default=0)
    idx: Mapped[int] = mapped_column(Integer)
    start_ms: Mapped[int] = mapped_column(Integer)
    end_ms: Mapped[int] = mapped_column(Integer)
    speaker: Mapped[str | None] = mapped_column(String(32), nullable=True)
    text: Mapped[str] = mapped_column(Text)
    original_text: Mapped[str] = mapped_column(Text)
    edited: Mapped[bool] = mapped_column(Boolean, default=False)

    recording: Mapped[Recording] = relationship(back_populates="segments")


class TranscriptionJob(Base):
    __tablename__ = "transcription_jobs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    recording_id: Mapped[str] = mapped_column(String(36), index=True)
    part_id: Mapped[str] = mapped_column(String(36), index=True)
    upload_id: Mapped[str] = mapped_column(String(36))
    status: Mapped[str] = mapped_column(String(20), default="queued")  # queued|running|done|failed
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    provider: Mapped[str | None] = mapped_column(String(40), nullable=True)
    audio_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    latency_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    refine_applied: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class EventLog(Base):
    """سجل تدقيق/تحميلات/فشل يُعرض للمستخدم ويُستخدم للمراقبة."""

    __tablename__ = "event_log"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    owner_id: Mapped[str] = mapped_column(String(64), index=True)
    recording_id: Mapped[str | None] = mapped_column(String(36), nullable=True, index=True)
    kind: Mapped[str] = mapped_column(String(40))  # upload_started|upload_completed|upload_failed|stt_done|stt_failed|conflict
    message: Mapped[str] = mapped_column(Text, default="")
    at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


def next_change_seq(db: Session, owner_id: str) -> int:
    current = db.scalar(select(func.max(Recording.change_seq)).where(Recording.owner_id == owner_id))
    return (current or 0) + 1


def log_event(db: Session, owner_id: str, kind: str, message: str = "", recording_id: str | None = None) -> None:
    db.add(EventLog(owner_id=owner_id, kind=kind, message=message[:2000], recording_id=recording_id))
