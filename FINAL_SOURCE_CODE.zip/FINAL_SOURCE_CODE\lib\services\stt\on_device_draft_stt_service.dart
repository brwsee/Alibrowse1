import 'package:uuid/uuid.dart';
import '../../core/sync/hlc_clock.dart';
import '../../domain/models/knowledge_entry.dart';

/// عنصر في القاموس الشخصي لتحسين دقة التفريغ للمصطلحات النادرة والأسماء
class CustomVocabularyTerm {
  final String term;
  final String phoneticHint;
  final ArabicDialect dialect;

  const CustomVocabularyTerm({
    required this.term,
    this.phoneticHint = '',
    this.dialect = ArabicDialect.auto,
  });
}

/// خدمة الفهرسة الصوتية المبدئية على الجهاز (On-Device Edge Draft Indexer)
/// تعمل بدون إنترنت فور انتهاء التسجيل (≤ دقيقتين) لتقسيم الصوت إلى فقرات زمنية
/// وإتاحة إضافة علامات مرجعية (Bookmarks) وكلمات مفتاحية قابلة للبحث قبل الاتصال بالسحابة
class OnDeviceDraftSttService {
  final HybridLogicalClock _hlcClock;
  final _uuid = const Uuid();

  /// القاموس الشخصي للمستخدم (يُمرر أيضاً للسحابة عند توفر الإنترنت)
  final List<CustomVocabularyTerm> _customVocabulary = [
    const CustomVocabularyTerm(term: 'المكتبة المعرفية الذكية'),
    const CustomVocabularyTerm(term: 'تفريغ نصي'),
    const CustomVocabularyTerm(term: 'طوابع زمنية'),
  ];

  OnDeviceDraftSttService({required HybridLogicalClock hlcClock})
      : _hlcClock = hlcClock;

  List<CustomVocabularyTerm> get customVocabulary =>
      List.unmodifiable(_customVocabulary);

  void addVocabularyTerm(String term, {ArabicDialect dialect = ArabicDialect.auto}) {
    final cleaned = term.trim();
    if (cleaned.isEmpty) return;
    if (!_customVocabulary.any((t) => t.term == cleaned)) {
      _customVocabulary.add(
        CustomVocabularyTerm(term: cleaned, dialect: dialect),
      );
    }
  }

  void removeVocabularyTerm(String term) {
    _customVocabulary.removeWhere((t) => t.term == term);
  }

  /// توليد فقرات زمنية مبدئية محلياً (On-Device VAD & Draft Segmentation)
  /// تقسم المقطع (الذي لا يتعدى 120 ثانية) بناءً على العلامات المرجعية (Bookmarks)
  /// أو إلى مقاطع زمنية منتظمة كل 20 ثانية لتسهيل تدوين الملاحظات الفورية بدون إنترنت
  List<TranscriptSegment> generateOfflineDraftSegments({
    required String entryId,
    required int durationMs,
    required ArabicDialect dialect,
    List<int> bookmarkTimestampsMs = const [],
    String? quickKeywordsNote,
  }) {
    final hlc = _hlcClock.now();
    final clampedDuration = durationMs.clamp(1000, 120000);

    // تحديد نقاط التقسيم الزمني بناءً على العلامات المرجعية أو كل 20 ثانية
    final splitPoints = <int>{0, clampedDuration};
    for (final bm in bookmarkTimestampsMs) {
      if (bm > 500 && bm < clampedDuration - 500) {
        splitPoints.add(bm);
      }
    }

    if (splitPoints.length == 2 && clampedDuration > 25000) {
      for (var t = 20000; t < clampedDuration; t += 20000) {
        splitPoints.add(t);
      }
    }

    final sortedPoints = splitPoints.toList()..sort();
    final segments = <TranscriptSegment>[];

    for (var i = 0; i < sortedPoints.length - 1; i++) {
      final start = sortedPoints[i];
      final end = sortedPoints[i + 1];
      final isBookmark = bookmarkTimestampsMs.contains(start);

      final draftLabel = StringBuffer()
        ..write(
          isBookmark
              ? '[علامة مرجعية هامة ★] '
              : '[مسودة محلية ${i + 1} - ${dialect.label}] ',
        );

      if (i == 0 &&
          quickKeywordsNote != null &&
          quickKeywordsNote.trim().isNotEmpty) {
        draftLabel.write('${quickKeywordsNote.trim()} — ');
      }

      draftLabel.write(
        'سيتم استبدال هذه الفقرة بالتفريغ العربي الدقيق تلقائياً فور الاتصال بالإنترنت.',
      );

      final text = draftLabel.toString();
      segments.add(
        TranscriptSegment(
          id: _uuid.v4(),
          entryId: entryId,
          segmentIndex: i,
          startMs: start,
          endMs: end,
          rawText: text,
          editedText: text,
          confidence: 0.65,
          isUserModified: false,
          hlcTimestamp: hlc,
        ),
      );
    }

    return segments;
  }
}
