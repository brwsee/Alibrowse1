from __future__ import annotations

from pathlib import Path

from .base import SttResult, Word


class FakeSttProvider:
    """مزود وهمي حتمي للاختبارات والتطوير دون اتصال."""

    name = "fake"

    def __init__(self, words: list[Word] | None = None):
        self._words = words or [
            Word("السلام", 0, 400, "spk_1"),
            Word("عليكم", 450, 900, "spk_1"),
            Word("اممم", 950, 1200, "spk_1"),
            Word("اليوم", 2500, 2900, "spk_1"),
            Word("نتكلم", 2950, 3400, "spk_1"),
            Word("عن", 3450, 3600, "spk_1"),
            Word("المكتبة", 3650, 4200, "spk_1"),
            Word("تمام", 5200, 5600, "spk_2"),
        ]

    def transcribe(self, audio_path: Path, *, language_codes: list[str], diarize: bool) -> SttResult:
        assert audio_path.exists()
        return SttResult(words=list(self._words), text=" ".join(w.text for w in self._words), provider=self.name)


class FakeRefiner:
    def __init__(self, mapping=None):  # noqa: ANN001
        self._mapping = mapping

    def refine(self, paragraphs: list[str]) -> list[str] | None:
        if self._mapping is None:
            return [p.rstrip(".") + "." for p in paragraphs]
        return self._mapping(paragraphs)
