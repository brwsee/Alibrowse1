import 'package:flutter_test/flutter_test.dart';
import 'package:smart_knowledge_library/core/benchmark/golden_arabic_dataset.dart';
import 'package:smart_knowledge_library/core/constants/app_constants.dart';
import 'package:smart_knowledge_library/core/sync/conflict_resolver.dart';
import 'package:smart_knowledge_library/core/sync/hlc_clock.dart';
import 'package:smart_knowledge_library/core/utils/arabic_text_evaluator.dart';
import 'package:smart_knowledge_library/domain/models/knowledge_entry.dart';
import 'package:smart_knowledge_library/services/audio/audio_recorder_service.dart';
import 'package:smart_knowledge_library/services/export/transcript_export_service.dart';
import 'package:smart_knowledge_library/services/stt/on_device_draft_stt_service.dart';

void main() {
  group('قيود مدة المقطع الصوتي (الحد الأقصى دقيقتان = 120 ثانية)', () {
    test('التحقق من ثوابت المدة القصوى والتنبيه', () {
      expect(AppConstants.maxRecordingDurationSeconds, equals(120));
      expect(AppConstants.warningThresholdSeconds, equals(105));
    });

    test('حساب الوقت المتبقي ومنطقة التنبيه في جلسة التسجيل', () {
      const stateAtStart = RecordingSessionState(
        isRecording: true,
        elapsedSeconds: 30,
      );
      expect(stateAtStart.remainingSeconds, equals(90));
      expect(stateAtStart.isNearLimit, isFalse);
      expect(stateAtStart.formattedElapsed, equals('00:30'));
      expect(stateAtStart.formattedRemaining, equals('01:30'));

      const stateNearEnd = RecordingSessionState(
        isRecording: true,
        elapsedSeconds: 110,
      );
      expect(stateNearEnd.remainingSeconds, equals(10));
      expect(stateNearEnd.isNearLimit, isTrue);
    });
  });

  group('اختبارات دقة التفريغ العربي المطبّع (Arabic STT Evaluator)', () {
    test('تجاهل التشكيل وتوحيد الهمزات والتاء المربوطة عند القياس', () {
      const reference =
          'المَكْتَبَةُ المَعْرِفِيَّةُ الذَّكِيَّةُ تَحْفَظُ الملاحظةَ.';
      const hypothesis = 'المكتبه المعرفيه الذكيه تحفظ الملاحظه';

      final wer = ArabicTextEvaluator.calculateNormalizedWer(
        reference,
        hypothesis,
      );
      final accuracy = ArabicTextEvaluator.calculateAccuracyPercentage(
        reference,
        hypothesis,
      );

      expect(wer, equals(0.0));
      expect(accuracy, equals(100.0));
    });
  });

  group('الساعة المنطقية الهجينة وحل التعارضات (HLC & ConflictResolver)', () {
    test('توليد طوابع زمنية مرتبة تصاعدياً دائماً وحل تعارض جهازين', () {
      final clock = HybridLogicalClock(nodeId: 'device-a');
      final resolver = ConflictResolver(hlcClock: clock);

      final t1 = clock.now();
      final t2 = clock.now();
      expect(t2.compareTo(t1), greaterThan(0));

      final localSeg = TranscriptSegment(
        id: 'seg-1',
        entryId: 'entry-1',
        segmentIndex: 0,
        startMs: 0,
        endMs: 15000,
        rawText: 'نص أولي',
        editedText: 'تعديل الجهاز الأول',
        isUserModified: true,
        hlcTimestamp: t1,
      );

      final remoteSeg = TranscriptSegment(
        id: 'seg-1',
        entryId: 'entry-1',
        segmentIndex: 0,
        startMs: 0,
        endMs: 15000,
        rawText: 'نص أولي',
        editedText: 'تعديل الجهاز الثاني',
        isUserModified: true,
        hlcTimestamp: t2,
      );

      final result = resolver.resolveSegments(
        localSegments: [localSeg],
        remoteSegments: [remoteSeg],
      );

      expect(result.manualConflicts.length, equals(1));
      final merged = resolver.mergeBothVersions(result.manualConflicts.first);
      expect(merged.editedText, contains('تعديل الجهاز الأول'));
      expect(merged.editedText, contains('تعديل الجهاز الثاني'));
    });
  });

  group('تصدير التفريغ النصي (Markdown & SRT)', () {
    test('توليد صيغة SRT بالطوابع الزمنية الصحيحة', () {
      final exporter = TranscriptExportService();
      final now = DateTime(2026, 11, 2, 10, 30);
      final entry = KnowledgeEntry(
        id: '12345678-abcd',
        title: 'محاضرة الذكاء الاصطناعي',
        recordedAt: now,
        durationMs: 25000,
        fileSizeBytes: 120000,
        fileSha256: 'abc123sha',
        encryptionIv: 'iv123',
        hlcTimestamp: '0001-0000-node',
        createdAt: now,
        updatedAt: now,
        segments: const [
          TranscriptSegment(
            id: 's1',
            entryId: '12345678-abcd',
            segmentIndex: 0,
            startMs: 0,
            endMs: 12500,
            rawText: 'مرحبا بكم',
            editedText: 'مرحباً بكم في المكتبة المعرفية.',
            hlcTimestamp: '0001-0000-node',
          ),
        ],
      );

      final srt = exporter.formatEntry(entry, TranscriptExportFormat.srt);
      expect(srt, contains('00:00:00,000 --> 00:00:12,500'));
      expect(srt, contains('مرحباً بكم في المكتبة المعرفية.'));
    });
  });

  group('الفهرسة المحلية المبدئية وحزمة اختبار اللهجات العربية', () {
    test('تقسيم المقطع بدون إنترنت بناءً على العلامات المرجعية (Bookmarks)', () {
      final clock = HybridLogicalClock(nodeId: 'edge-node');
      final draftService = OnDeviceDraftSttService(hlcClock: clock);

      final segments = draftService.generateOfflineDraftSegments(
        entryId: 'entry-offline-1',
        durationMs: 60000,
        dialect: ArabicDialect.gulf,
        bookmarkTimestampsMs: [15000, 40000],
        quickKeywordsNote: 'اجتماع الربع الرابع',
      );

      expect(segments.length, equals(3));
      expect(segments[0].startMs, equals(0));
      expect(segments[0].endMs, equals(15000));
      expect(segments[1].startMs, equals(15000));
      expect(segments[1].editedText, contains('علامة مرجعية هامة ★'));
    });

    test('نجاح جميع حالات الاختبار الذهبية للهجات العربية الخمس', () {
      final summary = GoldenArabicBenchmarkSuite.runAllBenchmarks();
      expect(summary.passedCount, equals(summary.totalCount));
      expect(summary.averageAccuracyPercent, greaterThanOrEqualTo(90.0));
    });
  });
}
