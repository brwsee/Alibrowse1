from __future__ import annotations

import base64
import hashlib
import os
import sys
import uuid
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.config import Settings  # noqa: E402
from app.crypto import encrypt_bytes, wrap_key  # noqa: E402
from app.main import create_app  # noqa: E402
from app.stt.fake_provider import FakeRefiner, FakeSttProvider  # noqa: E402


@pytest.fixture()
def settings(tmp_path: Path) -> Settings:
    return Settings(
        data_dir=tmp_path,
        database_url=f"sqlite:///{tmp_path / 'test.db'}",
        jwt_secret="test-secret",
        dev_mode=True,
        worker_inline=True,
        max_chunk_bytes=64 * 1024,
    )


@pytest.fixture()
def app(settings):
    return create_app(settings, provider=FakeSttProvider(), refiner=FakeRefiner())


@pytest.fixture()
def client(app):
    with TestClient(app) as c:
        yield c


def token_for(client: TestClient, user="u1", device="phone-A") -> dict:
    t = client.post("/v1/auth/dev-token", json={"user_id": user, "device_id": device}).json()["token"]
    return {"Authorization": f"Bearer {t}"}


def register_recording(client: TestClient, headers: dict, n_parts: int = 1) -> tuple[str, list[str]]:
    rec_id = str(uuid.uuid4())
    parts = [str(uuid.uuid4()) for _ in range(n_parts)]
    body = {
        "id": rec_id, "title": "ملاحظة", "recorded_at": "2026-11-01T08:00:00Z", "duration_ms": 6000 * n_parts,
        "codec": "wav", "sample_rate": 16000, "latitude": 24.7, "longitude": 46.7,
        "parts": [{"id": p, "part_index": i, "duration_ms": 6000} for i, p in enumerate(parts)],
    }
    r = client.put(f"/v1/recordings/{rec_id}", json=body, headers=headers)
    assert r.status_code == 200, r.text
    return rec_id, parts


def encrypted_payload(app, plain: bytes) -> tuple[bytes, dict]:
    dek = os.urandom(32)
    blob = encrypt_bytes(plain, dek, chunk_size=4096)
    meta = {
        "sha256": hashlib.sha256(blob).hexdigest(),
        "key_id": app.state.keys.key_id,
        "wrapped_key": wrap_key(app.state.keys.public_key(), dek),
        "codec": "wav",
    }
    return blob, meta


def tus_metadata(d: dict) -> str:
    return ",".join(f"{k} {base64.b64encode(v.encode()).decode()}" for k, v in d.items())
