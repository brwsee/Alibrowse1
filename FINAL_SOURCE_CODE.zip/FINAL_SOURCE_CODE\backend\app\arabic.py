"""أدوات معالجة النص العربي: تطبيع للبحث/القياس، إزالة الحشو، وتنظيف الترقيم.

ملاحظة: التطبيع هنا للمقارنة والبحث فقط — لا يُطبَّق على النص المعروض للمستخدم.
"""
from __future__ import annotations

import re
import unicodedata

# التشكيل + علامات قرآنية + التطويل
_DIACRITICS = re.compile(r"[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640]")
_ALEF = re.compile(r"[\u0622\u0623\u0625\u0671]")  # آ أ إ ٱ -> ا
_PUNCT = re.compile(r"[^\w\s]|_", re.UNICODE)
_SPACES = re.compile(r"\s+")
_ARABIC_INDIC = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")

# كلمات حشو شائعة في اللهجات (تُزال في وضع العرض المنسق فقط).
# تحذير: لا تُضف "ام"/"امم" لأنها تطابق بعد التطبيع كلمات حقيقية مثل «أم» و«أمم».
FILLERS = {"اممم", "ممم", "اه", "آه", "ااه", "ههه", "uh", "um"}

_LATIN_PUNCT_TO_AR = {",": "،", "?": "؟", ";": "؛"}


def normalize_for_matching(text: str, *, fold_ta_marbuta: bool = True, fold_ya: bool = True) -> str:
    """تطبيع قياسي لقياس WER/CER والبحث النصي (يتبع أعراف تقييم ASR العربي الشائعة)."""
    t = unicodedata.normalize("NFKC", text)
    t = t.translate(_ARABIC_INDIC)
    t = _DIACRITICS.sub("", t)
    t = _ALEF.sub("ا", t)
    if fold_ta_marbuta:
        t = t.replace("ة", "ه")
    if fold_ya:
        t = t.replace("ى", "ي")
    t = t.replace("ؤ", "ء").replace("ئ", "ء")
    t = _PUNCT.sub(" ", t)
    t = _SPACES.sub(" ", t).strip().lower()
    return t


def strip_fillers(text: str) -> str:
    fillers = {normalize_for_matching(f) for f in FILLERS}
    return " ".join(w for w in text.split() if normalize_for_matching(w) not in fillers)


def tidy_punctuation(text: str, *, ensure_terminal: bool = True) -> str:
    """تحويل الترقيم اللاتيني إلى عربي داخل سياق عربي، وضبط المسافات، وإضافة نقطة ختامية."""
    t = _SPACES.sub(" ", text).strip()
    if not t:
        return t
    if re.search(r"[\u0600-\u06FF]", t):
        for latin, ar in _LATIN_PUNCT_TO_AR.items():
            t = t.replace(latin, ar)
    t = re.sub(r"\s+([،؛؟.!:])", r"\1", t)  # لا مسافة قبل علامة الترقيم
    t = re.sub(r"([،؛؟.!:])(?=[^\s\d])", r"\1 ", t)  # مسافة بعدها
    if ensure_terminal and t[-1] not in ".؟!…:":
        t += "."
    return t
