"""خط معالجة التفريغ: فك التشفير ← STT ← تقسيم فقرات ← تحسين لغوي محروس ← حفظ."""
from __future__ import annotations

import logging
import threading
import time
import uuid
from pathlib import Path

from sqlalchemy import delete, func, select
from sqlalchemy.orm import Session, sessionmaker

from .config import Settings
from .crypto import KeyManager, decrypt_file
from .metrics import Metrics
from .models import (
    Recording,
    RecordingPart,
    Segment,
    TranscriptionJob,
    Upload,
    log_event,
    next_change_seq,
    utcnow,
)
from .quality import cer
from .segmenter import segment_words
from .stt.base import SttProvider, TextRefiner

log = logging.getLogger("skl.pipeline")

MAX_ATTEMPTS = 3
_CODEC_EXT = {"wav": "wav", "opus": "ogg", "aac": "m4a", "flac": "flac"}
# Gemini 3.5 Transcribe يدعم ar-EG صراحةً؛ بقية اللهجات تُترك للكشف التلقائي (يتعامل مع code-switching)
_DIALECT_LANG = {"ar-EG": ["ar-EG"]}


class TranscriptionPipeline:
    def __init__(
        self,
        settings: Settings,
        session_factory: sessionmaker[Session],
        keys: KeyManager,
        provider: SttProvider,
        refiner: TextRefiner | None,
        metrics: Metrics,
    ) -> None:
        self.settings = settings
        self.sf = session_factory
        self.keys = keys
        self.provider = provider
        self.refiner = refiner
        self.metrics = metrics
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    # ---------------------------------------------------------------- worker
    def start(self) -> None:
        if self.settings.worker_inline or self._thread:
            return
        self._thread = threading.Thread(target=self._loop, name="stt-worker", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def _loop(self) -> None:
        while not self._stop.is_set():
            job_id = self._claim_next()
            if job_id is None:
                self._stop.wait(2.0)
                continue
            self.process(job_id)

    def _claim_next(self) -> int | None:
        with self.sf() as db:
            candidates = db.scalars(
                select(TranscriptionJob).where(TranscriptionJob.status == "queued").order_by(TranscriptionJob.id).limit(50)
            )
            for job in candidates:
                # backoff أُسّي بسيط بين المحاولات
                waited = (utcnow() - (job.finished_at or job.created_at)).total_seconds()
                if job.attempts and waited < 15 * 2 ** job.attempts:
                    continue
                job.status = "running"
                db.commit()
                return job.id
            return None

    def enqueue(self, db: Session, upload: Upload) -> TranscriptionJob:
        job = TranscriptionJob(recording_id=upload.recording_id, part_id=upload.part_id, upload_id=upload.id)
        db.add(job)
        db.flush()
        return job

    # --------------------------------------------------------------- process
    def process(self, job_id: int) -> None:
        t0 = time.monotonic()
        with self.sf() as db:
            job = db.get(TranscriptionJob, job_id)
            upload = db.get(Upload, job.upload_id)
            part = db.get(RecordingPart, job.part_id)
            rec = db.get(Recording, job.recording_id)
            job.status, job.attempts = "running", job.attempts + 1
            rec.status = "transcribing"
            db.commit()

            plain = self.settings.tmp_dir / f"{uuid.uuid4()}.{_CODEC_EXT.get(upload.codec, 'bin')}"
            try:
                dek = self.keys.unwrap(upload.wrapped_key, upload.key_id)
                decrypt_file(self.settings.uploads_dir / f"{upload.id}.bin", plain, dek)
                del dek
                result = self.provider.transcribe(
                    plain,
                    language_codes=_DIALECT_LANG.get(rec.dialect_hint or "", []),
                    diarize=True,
                )
                offset = db.scalar(
                    select(func.coalesce(func.sum(RecordingPart.duration_ms), 0)).where(
                        RecordingPart.recording_id == rec.id, RecordingPart.part_index < part.part_index
                    )
                )
                paragraphs = segment_words(
                    result.words,
                    pause_ms=self.settings.paragraph_pause_ms,
                    max_ms=self.settings.paragraph_max_ms,
                    offset_ms=int(offset or 0),
                )
                job.refine_applied = self._refine(paragraphs)

                db.execute(
                    delete(Segment).where(
                        Segment.recording_id == rec.id, Segment.part_index == part.part_index, Segment.edited.is_(False)
                    )
                )
                for p in paragraphs:
                    db.add(Segment(
                        recording_id=rec.id, seg_uid=str(uuid.uuid4()), part_index=part.part_index, idx=0,
                        start_ms=p.start_ms, end_ms=p.end_ms, speaker=p.speaker, text=p.text, original_text=p.raw_text,
                    ))
                db.flush()
                for i, seg in enumerate(
                    db.scalars(select(Segment).where(Segment.recording_id == rec.id).order_by(Segment.start_ms))
                ):
                    seg.idx = i

                if result.formatted_text:
                    rec.formatted_text = (
                        result.formatted_text if part.part_index == 0 or not rec.formatted_text
                        else rec.formatted_text + "\n\n" + result.formatted_text
                    )
                part.status = "transcribed"
                db.flush()
                pending = db.scalar(
                    select(func.count()).select_from(RecordingPart).where(
                        RecordingPart.recording_id == rec.id, RecordingPart.status != "transcribed"
                    )
                )
                rec.status = "transcribed" if pending == 0 else "transcribing"
                rec.version += 1
                rec.change_seq = next_change_seq(db, rec.owner_id)

                elapsed = time.monotonic() - t0
                job.status, job.provider, job.finished_at = "done", result.provider, utcnow()
                job.latency_ms, job.audio_ms = int(elapsed * 1000), part.duration_ms
                log_event(db, rec.owner_id, "stt_done", f"part {part.part_index}: {len(paragraphs)} paragraphs", rec.id)
                db.commit()
                self.metrics.stt_jobs.labels("done").inc()
                self.metrics.stt_latency.observe(elapsed)
                if part.duration_ms:
                    self.metrics.stt_rtf.observe(elapsed / (part.duration_ms / 1000))
            except Exception as exc:  # noqa: BLE001
                log.exception("transcription failed job=%s", job_id)
                db.rollback()
                job = db.get(TranscriptionJob, job_id)
                rec = db.get(Recording, job.recording_id)
                job.error, job.finished_at = f"{type(exc).__name__}: {exc}", utcnow()
                if job.attempts >= MAX_ATTEMPTS:
                    job.status = rec.status = "failed"
                    rec.change_seq = next_change_seq(db, rec.owner_id)
                    self.metrics.stt_jobs.labels("failed").inc()
                else:
                    job.status, rec.status = "queued", "queued"
                    self.metrics.stt_jobs.labels("retry").inc()
                log_event(db, rec.owner_id, "stt_failed", job.error, rec.id)
                db.commit()
            finally:
                plain.unlink(missing_ok=True)  # لا يبقى نص صريح على القرص

    def _refine(self, paragraphs) -> bool:  # noqa: ANN001
        if not (self.refiner and self.settings.refine_enabled and paragraphs):
            return False
        try:
            refined = self.refiner.refine([p.text for p in paragraphs])
        except Exception:  # noqa: BLE001
            log.warning("refiner failed; keeping raw paragraphs", exc_info=True)
            self.metrics.refine.labels("error").inc()
            return False
        if refined is None:
            self.metrics.refine.labels("invalid").inc()
            return False
        applied = False
        for p, new in zip(paragraphs, refined):
            # حارس الهلوسة: نرفض أي تحسين يبتعد عن الكلام المنطوق أكثر من العتبة
            if new.strip() and cer(p.text, new).rate <= self.settings.refine_max_drift_cer:
                p.text = new.strip()
                applied = True
                self.metrics.refine.labels("accepted").inc()
            else:
                self.metrics.refine.labels("rejected").inc()
        return applied


def remove_upload_blob(settings: Settings, upload_id: str) -> None:
    Path(settings.uploads_dir / f"{upload_id}.bin").unlink(missing_ok=True)
