"""تحويل الكلمات ذات الطوابع الزمنية إلى فقرات قابلة للعرض والتحرير."""
from __future__ import annotations

from dataclasses import dataclass

from .arabic import strip_fillers, tidy_punctuation
from .stt.base import Word


@dataclass
class Paragraph:
    start_ms: int
    end_ms: int
    speaker: str | None
    raw_text: str  # النص الحرفي كما خرج من STT
    text: str  # بعد إزالة الحشو وتنظيف الترقيم


def segment_words(
    words: list[Word], *, pause_ms: int = 700, max_ms: int = 30_000, offset_ms: int = 0
) -> list[Paragraph]:
    """قواعد الفصل: صمت ≥ pause_ms، أو تغيّر المتحدث، أو تجاوز max_ms مع وقفة قصيرة/علامة نهاية جملة."""
    paragraphs: list[Paragraph] = []
    bucket: list[Word] = []

    def flush() -> None:
        if not bucket:
            return
        raw = " ".join(w.text for w in bucket)
        cleaned = tidy_punctuation(strip_fillers(raw))
        if cleaned:
            paragraphs.append(
                Paragraph(
                    start_ms=bucket[0].start_ms + offset_ms,
                    end_ms=bucket[-1].end_ms + offset_ms,
                    speaker=bucket[0].speaker,
                    raw_text=raw,
                    text=cleaned,
                )
            )
        bucket.clear()

    for w in words:
        if bucket:
            prev = bucket[-1]
            gap = w.start_ms - prev.end_ms
            too_long = (w.end_ms - bucket[0].start_ms) > max_ms
            sentence_end = prev.text.endswith((".", "؟", "?", "!"))
            if (
                gap >= pause_ms
                or (w.speaker and prev.speaker and w.speaker != prev.speaker)
                or (too_long and (gap >= pause_ms // 3 or sentence_end))
                or (w.end_ms - bucket[0].start_ms) > max_ms * 2  # حد صارم
            ):
                flush()
        bucket.append(w)
    flush()
    return paragraphs
