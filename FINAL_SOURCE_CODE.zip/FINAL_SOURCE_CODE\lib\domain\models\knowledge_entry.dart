/// حالات التزامن الخاصة بالكيان المعرفي
enum SyncStatus {
  localOnly('LOCAL_ONLY', 'محفوظ محلياً'),
  uploading('UPLOADING', 'جارٍ الرفع...'),
  processing('PROCESSING', 'جارٍ التفريغ العربي...'),
  synced('SYNCED', 'متزامن ومفرّغ'),
  conflict('CONFLICT', 'يوجد تعارض'),
  failed('FAILED', 'فشل الرفع');

  final String code;
  final String arabicLabel;
  const SyncStatus(this.code, this.arabicLabel);

  static SyncStatus fromCode(String code) {
    return SyncStatus.values.firstWhere(
      (e) => e.code == code,
      orElse: () => SyncStatus.localOnly,
    );
  }
}

/// اللهجات العربية المدعومة لتحسين دقة التفريغ
enum ArabicDialect {
  auto('auto', 'تلقائي (ذكي)'),
  msa('msa', 'العربية الفصحى'),
  gulf('gulf', 'لهجة خليجية'),
  egyptian('egyptian', 'لهجة مصرية'),
  levantine('levantine', 'لهجة شامية'),
  maghrebi('maghrebi', 'لهجة مغاربية');

  final String code;
  final String label;
  const ArabicDialect(this.code, this.label);

  static ArabicDialect fromCode(String code) {
    return ArabicDialect.values.firstWhere(
      (e) => e.code == code,
      orElse: () => ArabicDialect.auto,
    );
  }
}

/// فقرة نصية واحدة مرتبطة بطابع زمني داخل التسجيل
class TranscriptSegment {
  final String id;
  final String entryId;
  final int segmentIndex;
  final int startMs;
  final int endMs;
  final String rawText;
  final String editedText;
  final double confidence;
  final String? speakerTag;
  final bool isUserModified;
  final String hlcTimestamp;

  const TranscriptSegment({
    required this.id,
    required this.entryId,
    required this.segmentIndex,
    required this.startMs,
    required this.endMs,
    required this.rawText,
    required this.editedText,
    this.confidence = 1.0,
    this.speakerTag,
    this.isUserModified = false,
    required this.hlcTimestamp,
  });

  /// تنسيق الطابع الزمني للعرض (MM:SS)
  String get formattedStartTime {
    final totalSeconds = startMs ~/ 1000;
    final minutes = (totalSeconds ~/ 60).toString().padLeft(2, '0');
    final seconds = (totalSeconds % 60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }

  TranscriptSegment copyWith({
    String? editedText,
    bool? isUserModified,
    String? hlcTimestamp,
  }) {
    return TranscriptSegment(
      id: id,
      entryId: entryId,
      segmentIndex: segmentIndex,
      startMs: startMs,
      endMs: endMs,
      rawText: rawText,
      editedText: editedText ?? this.editedText,
      confidence: confidence,
      speakerTag: speakerTag,
      isUserModified: isUserModified ?? this.isUserModified,
      hlcTimestamp: hlcTimestamp ?? this.hlcTimestamp,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'entry_id': entryId,
      'segment_index': segmentIndex,
      'start_ms': startMs,
      'end_ms': endMs,
      'raw_text': rawText,
      'edited_text': editedText,
      'confidence': confidence,
      'speaker_tag': speakerTag,
      'is_user_modified': isUserModified ? 1 : 0,
      'hlc_timestamp': hlcTimestamp,
    };
  }

  factory TranscriptSegment.fromMap(Map<String, dynamic> map) {
    return TranscriptSegment(
      id: map['id'] as String,
      entryId: map['entry_id'] as String,
      segmentIndex: map['segment_index'] as int,
      startMs: map['start_ms'] as int,
      endMs: map['end_ms'] as int,
      rawText: map['raw_text'] as String,
      editedText: map['edited_text'] as String,
      confidence: (map['confidence'] as num?)?.toDouble() ?? 1.0,
      speakerTag: map['speaker_tag'] as String?,
      isUserModified: (map['is_user_modified'] as int? ?? 0) == 1,
      hlcTimestamp: map['hlc_timestamp'] as String,
    );
  }
}

/// الكيان المعرفي الموحد (التسجيل الصوتي + البيانات الوصفية + الفقرات النصية)
class KnowledgeEntry {
  final String id;
  final String title;
  final DateTime recordedAt;
  final int durationMs;
  final String audioFormat; // 'opus' | 'wav'
  final int sampleRate;
  final String? localFilePath;
  final int fileSizeBytes;
  final String fileSha256;
  final String encryptionIv;
  final double? latitude;
  final double? longitude;
  final String? placeName;
  final ArabicDialect dialectHint;
  final SyncStatus syncStatus;
  final String hlcTimestamp;
  final int version;
  final bool isDeleted;
  final DateTime createdAt;
  final DateTime updatedAt;
  final List<TranscriptSegment> segments;

  const KnowledgeEntry({
    required this.id,
    required this.title,
    required this.recordedAt,
    required this.durationMs,
    this.audioFormat = 'opus',
    this.sampleRate = 16000,
    this.localFilePath,
    required this.fileSizeBytes,
    required this.fileSha256,
    required this.encryptionIv,
    this.latitude,
    this.longitude,
    this.placeName,
    this.dialectHint = ArabicDialect.auto,
    this.syncStatus = SyncStatus.localOnly,
    required this.hlcTimestamp,
    this.version = 1,
    this.isDeleted = false,
    required this.createdAt,
    required this.updatedAt,
    this.segments = const [],
  });

  /// النص الكامل المجمّع للنسخ السريع أو التصدير
  String get fullTranscriptText =>
      segments.map((s) => s.editedText.trim()).join('\n\n');

  /// النص الكامل مع الطوابع الزمنية
  String get fullTranscriptWithTimestamps => segments
      .map((s) => '[${s.formattedStartTime}] ${s.editedText.trim()}')
      .join('\n');

  KnowledgeEntry copyWith({
    String? title,
    String? localFilePath,
    SyncStatus? syncStatus,
    String? hlcTimestamp,
    int? version,
    DateTime? updatedAt,
    List<TranscriptSegment>? segments,
  }) {
    return KnowledgeEntry(
      id: id,
      title: title ?? this.title,
      recordedAt: recordedAt,
      durationMs: durationMs,
      audioFormat: audioFormat,
      sampleRate: sampleRate,
      localFilePath: localFilePath ?? this.localFilePath,
      fileSizeBytes: fileSizeBytes,
      fileSha256: fileSha256,
      encryptionIv: encryptionIv,
      latitude: latitude,
      longitude: longitude,
      placeName: placeName,
      dialectHint: dialectHint,
      syncStatus: syncStatus ?? this.syncStatus,
      hlcTimestamp: hlcTimestamp ?? this.hlcTimestamp,
      version: version ?? this.version,
      isDeleted: isDeleted,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      segments: segments ?? this.segments,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'recorded_at': recordedAt.millisecondsSinceEpoch,
      'duration_ms': durationMs,
      'audio_format': audioFormat,
      'sample_rate': sampleRate,
      'local_file_path': localFilePath,
      'file_size_bytes': fileSizeBytes,
      'file_sha256': fileSha256,
      'encryption_iv': encryptionIv,
      'latitude': latitude,
      'longitude': longitude,
      'place_name': placeName,
      'dialect_hint': dialectHint.code,
      'sync_status': syncStatus.code,
      'hlc_timestamp': hlcTimestamp,
      'version': version,
      'is_deleted': isDeleted ? 1 : 0,
      'created_at': createdAt.millisecondsSinceEpoch,
      'updated_at': updatedAt.millisecondsSinceEpoch,
    };
  }

  factory KnowledgeEntry.fromMap(
    Map<String, dynamic> map, {
    List<TranscriptSegment> segments = const [],
  }) {
    return KnowledgeEntry(
      id: map['id'] as String,
      title: map['title'] as String,
      recordedAt: DateTime.fromMillisecondsSinceEpoch(map['recorded_at'] as int),
      durationMs: map['duration_ms'] as int,
      audioFormat: map['audio_format'] as String? ?? 'opus',
      sampleRate: map['sample_rate'] as int? ?? 16000,
      localFilePath: map['local_file_path'] as String?,
      fileSizeBytes: map['file_size_bytes'] as int,
      fileSha256: map['file_sha256'] as String,
      encryptionIv: map['encryption_iv'] as String,
      latitude: (map['latitude'] as num?)?.toDouble(),
      longitude: (map['longitude'] as num?)?.toDouble(),
      placeName: map['place_name'] as String?,
      dialectHint: ArabicDialect.fromCode(map['dialect_hint'] as String? ?? 'auto'),
      syncStatus: SyncStatus.fromCode(map['sync_status'] as String? ?? 'LOCAL_ONLY'),
      hlcTimestamp: map['hlc_timestamp'] as String,
      version: map['version'] as int? ?? 1,
      isDeleted: (map['is_deleted'] as int? ?? 0) == 1,
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['created_at'] as int),
      updatedAt: DateTime.fromMillisecondsSinceEpoch(map['updated_at'] as int),
      segments: segments,
    );
  }
}

/// عنصر في طابور الرفع القابل للاستئناف (Resumable Upload Task)
class UploadQueueItem {
  final String entryId;
  final String? tusUploadUrl;
  final int bytesUploaded;
  final int totalBytes;
  final int retryCount;
  final DateTime? nextRetryAt;
  final String? lastErrorCode;
  final String? lastErrorMessage;
  final DateTime updatedAt;

  const UploadQueueItem({
    required this.entryId,
    this.tusUploadUrl,
    this.bytesUploaded = 0,
    required this.totalBytes,
    this.retryCount = 0,
    this.nextRetryAt,
    this.lastErrorCode,
    this.lastErrorMessage,
    required this.updatedAt,
  });

  double get progress =>
      totalBytes > 0 ? (bytesUploaded / totalBytes).clamp(0.0, 1.0) : 0.0;

  Map<String, dynamic> toMap() {
    return {
      'entry_id': entryId,
      'tus_upload_url': tusUploadUrl,
      'bytes_uploaded': bytesUploaded,
      'total_bytes': totalBytes,
      'retry_count': retryCount,
      'next_retry_at': nextRetryAt?.millisecondsSinceEpoch,
      'last_error_code': lastErrorCode,
      'last_error_message': lastErrorMessage,
      'updated_at': updatedAt.millisecondsSinceEpoch,
    };
  }

  factory UploadQueueItem.fromMap(Map<String, dynamic> map) {
    return UploadQueueItem(
      entryId: map['entry_id'] as String,
      tusUploadUrl: map['tus_upload_url'] as String?,
      bytesUploaded: map['bytes_uploaded'] as int? ?? 0,
      totalBytes: map['total_bytes'] as int,
      retryCount: map['retry_count'] as int? ?? 0,
      nextRetryAt: map['next_retry_at'] != null
          ? DateTime.fromMillisecondsSinceEpoch(map['next_retry_at'] as int)
          : null,
      lastErrorCode: map['last_error_code'] as String?,
      lastErrorMessage: map['last_error_message'] as String?,
      updatedAt: DateTime.fromMillisecondsSinceEpoch(map['updated_at'] as int),
    );
  }
}
