from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol


@dataclass
class Word:
    text: str
    start_ms: int
    end_ms: int
    speaker: str | None = None


@dataclass
class SttResult:
    words: list[Word]
    text: str
    provider: str
    formatted_text: str | None = None
    meta: dict = field(default_factory=dict)


class SttProvider(Protocol):
    name: str

    def transcribe(self, audio_path: Path, *, language_codes: list[str], diarize: bool) -> SttResult: ...


class TextRefiner(Protocol):
    def refine(self, paragraphs: list[str]) -> list[str] | None: ...
