/// أداة قياس وتقييم دقة التفريغ النصي العربي (Arabic STT Quality Evaluator)
/// تُستخدم لحساب معدل خطأ الكلمات المطبّع (Normalized Arabic WER)
/// ومؤشر تعديل المستخدم (User Edit Distance Telemetry)
class ArabicTextEvaluator {
  /// تطبيع النص العربي قبل المقارنة الصوتية/النصية:
  /// - إزالة التشكيل (الحركات) والمد (التطويل)
  /// - توحيد أشكال الألف (أ، إ، آ، ٱ -> ا)
  /// - توحيد الهمزات والألف المقصورة (ى -> ي) والتاء المربوطة عند الوقف (ة -> ه)
  /// - إزالة علامات الترقيم والمسافات المكررة
  static String normalizeArabic(String input) {
    var text = input.trim();

    // 1. إزالة التشكيل العربي (الحركات) والـ Tatweel (ـ)
    final diacriticsRegex = RegExp(r'[\u064B-\u065F\u0670\u0640]');
    text = text.replaceAll(diacriticsRegex, '');

    // 2. توحيد أشكال الألف
    text = text.replaceAll(RegExp(r'[أإآٱ]'), 'ا');

    // 3. توحيد الألف المقصورة إلى ياء
    text = text.replaceAll('ى', 'ي');

    // 4. توحيد التاء المربوطة إلى هاء (لأنها تُنطق هاءً عند الوقف الصوتي)
    text = text.replaceAll('ة', 'ه');

    // 5. إزالة علامات الترقيم العربية والإنجليزية
    text = text.replaceAll(RegExp(r'[،؛؟.,!?;:"\-\(\)\[\]«»]'), ' ');

    // 6. توحيد المسافات المتعددة
    text = text.replaceAll(RegExp(r'\s+'), ' ').trim();

    return text;
  }

  /// حساب معدل خطأ الكلمات المطبّع للعربية (Normalized Arabic Word Error Rate - WER)
  /// النتيجة بين 0.0 (تطابق تام 100%) و 1.0+
  static double calculateNormalizedWer(String reference, String hypothesis) {
    final normRef = normalizeArabic(reference);
    final normHyp = normalizeArabic(hypothesis);

    if (normRef.isEmpty) return normHyp.isEmpty ? 0.0 : 1.0;

    final refWords = normRef.split(' ');
    final hypWords = normHyp.split(' ');

    final distance = _levenshteinDistance<String>(refWords, hypWords);
    return distance / refWords.length;
  }

  /// حساب دقة التفريغ المئوية (Arabic Transcription Accuracy %)
  static double calculateAccuracyPercentage(
    String reference,
    String hypothesis,
  ) {
    final wer = calculateNormalizedWer(reference, hypothesis);
    return ((1.0 - wer).clamp(0.0, 1.0)) * 100.0;
  }

  /// خوارزمية Levenshtein Distance العامة (تعمل على مستوى الكلمات أو الأحرف)
  static int _levenshteinDistance<T>(List<T> a, List<T> b) {
    final m = a.length;
    final n = b.length;

    final dp = List.generate(m + 1, (_) => List<int>.filled(n + 1, 0));

    for (var i = 0; i <= m; i++) {
      dp[i][0] = i;
    }
    for (var j = 0; j <= n; j++) {
      dp[0][j] = j;
    }

    for (var i = 1; i <= m; i++) {
      for (var j = 1; j <= n; j++) {
        final cost = a[i - 1] == b[j - 1] ? 0 : 1;
        final deletion = dp[i - 1][j] + 1;
        final insertion = dp[i][j - 1] + 1;
        final substitution = dp[i - 1][j - 1] + cost;

        var minVal = deletion < insertion ? deletion : insertion;
        if (substitution < minVal) minVal = substitution;
        dp[i][j] = minVal;
      }
    }

    return dp[m][n];
  }
}
