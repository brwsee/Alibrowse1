import hashlib
import uuid

from conftest import encrypted_payload, register_recording, token_for, tus_metadata

WAV_LIKE = b"RIFF" + b"\x00" * 200_000


def _create(client, app, headers, rec_id, part_id, plain=WAV_LIKE):
    blob, meta = encrypted_payload(app, plain)
    meta.update({"recording_id": rec_id, "part_id": part_id})
    r = client.post("/v1/uploads", headers={**headers, "Tus-Resumable": "1.0.0", "Upload-Length": str(len(blob)),
                                            "Upload-Metadata": tus_metadata(meta)})
    return r, blob


def _patch(client, headers, location, offset, chunk):
    import base64
    return client.patch(location, content=chunk, headers={
        **headers, "Tus-Resumable": "1.0.0", "Upload-Offset": str(offset),
        "Content-Type": "application/offset+octet-stream",
        "Upload-Checksum": "sha256 " + base64.b64encode(hashlib.sha256(chunk).digest()).decode(),
    })


def test_resumable_upload_then_transcription(client, app):
    h = token_for(client)
    rec_id, (part_id,) = register_recording(client, h)
    r, blob = _create(client, app, h, rec_id, part_id)
    assert r.status_code == 201
    loc = r.headers["Location"]

    # ارفع نصف الملف ثم "انقطع الاتصال"
    half = len(blob) // 2
    step = 60 * 1024
    off = 0
    while off < half:
        chunk = blob[off:min(off + step, half)]
        assert _patch(client, h, loc, off, chunk).status_code == 204
        off += len(chunk)

    # استئناف: HEAD يعيد الإزاحة المؤكدة
    head = client.head(loc, headers=h)
    assert int(head.headers["Upload-Offset"]) == half

    # أكمل من الإزاحة المؤكدة
    while off < len(blob):
        chunk = blob[off:off + step]
        resp = _patch(client, h, loc, off, chunk)
        assert resp.status_code == 204, resp.text
        off += len(chunk)

    rec = client.get(f"/v1/recordings/{rec_id}", headers=h).json()
    assert rec["status"] == "transcribed"
    assert [s["text"] for s in rec["segments"]] == ["السلام عليكم.", "اليوم نتكلم عن المكتبة.", "تمام."]
    assert rec["segments"][0]["original_text"] == "السلام عليكم اممم"
    assert rec["version"] == 2

    # لا يبقى أي ملف صوتي صريح في tmp
    assert not any(app.state.settings.tmp_dir.iterdir())

    kinds = [e["kind"] for e in client.get("/v1/events", headers=h).json()]
    assert {"upload_started", "upload_completed", "stt_done"} <= set(kinds)

    metrics = client.get("/metrics").text
    assert 'skl_stt_jobs_total{outcome="done"} 1.0' in metrics


def test_wrong_offset_and_bad_checksum(client, app):
    h = token_for(client)
    rec_id, (part_id,) = register_recording(client, h)
    r, blob = _create(client, app, h, rec_id, part_id)
    loc = r.headers["Location"]
    assert _patch(client, h, loc, 100, blob[:100]).status_code == 409
    bad = client.patch(loc, content=blob[:100], headers={
        **h, "Upload-Offset": "0", "Content-Type": "application/offset+octet-stream",
        "Upload-Checksum": "sha256 AAAA"})
    assert bad.status_code == 460


def test_create_is_idempotent(client, app):
    h = token_for(client)
    rec_id, (part_id,) = register_recording(client, h)
    blob, meta = encrypted_payload(app, WAV_LIKE)
    meta.update({"recording_id": rec_id, "part_id": part_id})
    hdrs = {**h, "Upload-Length": str(len(blob)), "Upload-Metadata": tus_metadata(meta)}
    first = client.post("/v1/uploads", headers=hdrs)
    second = client.post("/v1/uploads", headers=hdrs)
    assert first.status_code == 201 and second.status_code == 200
    assert first.headers["Location"] == second.headers["Location"]


def test_integrity_failure_marks_upload_failed(client, app):
    h = token_for(client)
    rec_id, (part_id,) = register_recording(client, h)
    blob, meta = encrypted_payload(app, WAV_LIKE)
    meta.update({"recording_id": rec_id, "part_id": part_id, "sha256": "0" * 64})
    r = client.post("/v1/uploads", headers={**h, "Upload-Length": str(len(blob)), "Upload-Metadata": tus_metadata(meta)})
    loc = r.headers["Location"]
    off = 0
    while off < len(blob):
        chunk = blob[off:off + 60 * 1024]
        _patch(client, h, loc, off, chunk)
        off += len(chunk)
    assert client.head(loc, headers=h).headers["X-Upload-Status"] == "failed"


def test_upload_requires_registered_recording_and_ownership(client, app):
    h1, h2 = token_for(client, "u1"), token_for(client, "u2")
    rec_id, (part_id,) = register_recording(client, h1)
    r, _ = _create(client, app, h2, rec_id, part_id)
    assert r.status_code == 409
    r, _ = _create(client, app, h1, str(uuid.uuid4()), part_id)
    assert r.status_code == 409
    assert client.get(f"/v1/recordings/{rec_id}", headers=h2).status_code == 404


def test_multipart_recording_offsets_timestamps(client, app):
    h = token_for(client)
    rec_id, parts = register_recording(client, h, n_parts=2)
    for part_id in parts:
        r, blob = _create(client, app, h, rec_id, part_id)
        loc, off = r.headers["Location"], 0
        while off < len(blob):
            chunk = blob[off:off + 60 * 1024]
            assert _patch(client, h, loc, off, chunk).status_code == 204
            off += len(chunk)
    segs = client.get(f"/v1/recordings/{rec_id}", headers=h).json()["segments"]
    assert len(segs) == 6
    assert segs[3]["start_ms"] == 6000  # الجزء الثاني يبدأ بعد مدة الجزء الأول
    assert [s["idx"] for s in segs] == list(range(6))
