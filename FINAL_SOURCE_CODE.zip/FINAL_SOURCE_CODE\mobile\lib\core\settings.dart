import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum AudioPreset { sttOptimal, highQuality, compact }

extension AudioPresetInfo on AudioPreset {
  String get label => switch (this) {
        AudioPreset.sttOptimal => 'مثالي للتفريغ (WAV 16kHz)',
        AudioPreset.highQuality => 'جودة عالية (WAV 48kHz)',
        AudioPreset.compact => 'مضغوط (Opus 32kbps)',
      };
  String get codec => this == AudioPreset.compact ? 'opus' : 'wav';
  int get sampleRate => switch (this) {
        AudioPreset.sttOptimal => 16000,
        AudioPreset.highQuality => 48000,
        AudioPreset.compact => 16000,
      };
}

/// إعدادات المستخدم (غير حساسة) — الحساسة مثل رمز المصادقة في flutter_secure_storage.
class AppSettings extends ChangeNotifier {
  AppSettings(this._prefs);
  final SharedPreferences _prefs;

  static Future<AppSettings> load() async => AppSettings(await SharedPreferences.getInstance());

  String get serverUrl => _prefs.getString('serverUrl') ?? const String.fromEnvironment(
      'SKL_SERVER', defaultValue: 'https://api.example.com');
  bool get autoSync => _prefs.getBool('autoSync') ?? true;
  bool get wifiOnly => _prefs.getBool('wifiOnly') ?? false;
  bool get saveLocation => _prefs.getBool('saveLocation') ?? false; // اختياري ومعطل افتراضياً
  AudioPreset get audioPreset => AudioPreset.values[_prefs.getInt('audioPreset') ?? 0];
  String? get dialectHint => _prefs.getString('dialectHint');
  int get storageLimitMb => _prefs.getInt('storageLimitMb') ?? 2048;
  bool get offloadUploadedAudio => _prefs.getBool('offloadUploadedAudio') ?? true;
  bool get privacyAccepted => _prefs.getBool('privacyAccepted') ?? false;

  Future<void> _set(Future<bool> f) async {
    await f;
    notifyListeners();
  }

  Future<void> setServerUrl(String v) => _set(_prefs.setString('serverUrl', v.trim()));
  Future<void> setAutoSync(bool v) => _set(_prefs.setBool('autoSync', v));
  Future<void> setWifiOnly(bool v) => _set(_prefs.setBool('wifiOnly', v));
  Future<void> setSaveLocation(bool v) => _set(_prefs.setBool('saveLocation', v));
  Future<void> setAudioPreset(AudioPreset v) => _set(_prefs.setInt('audioPreset', v.index));
  Future<void> setDialectHint(String? v) =>
      _set(v == null ? _prefs.remove('dialectHint') : _prefs.setString('dialectHint', v));
  Future<void> setStorageLimitMb(int v) => _set(_prefs.setInt('storageLimitMb', v));
  Future<void> setOffloadUploadedAudio(bool v) => _set(_prefs.setBool('offloadUploadedAudio', v));
  Future<void> setPrivacyAccepted(bool v) => _set(_prefs.setBool('privacyAccepted', v));
}

const dialects = <String?, String>{
  null: 'كشف تلقائي (موصى به)',
  'ar-EG': 'مصرية',
  'ar-SA': 'خليجية / سعودية',
  'ar-LV': 'شامية',
  'ar-MA': 'مغاربية',
  'ar-IQ': 'عراقية',
  'ar': 'فصحى',
};
