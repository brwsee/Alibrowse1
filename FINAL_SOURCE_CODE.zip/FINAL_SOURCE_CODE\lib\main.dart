import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/logging/app_logger_service.dart';
import 'core/security/encryption_service.dart';
import 'core/sync/conflict_resolver.dart';
import 'core/sync/hlc_clock.dart';
import 'data/local/local_database.dart';
import 'domain/models/knowledge_entry.dart';
import 'presentation/screens/settings_and_diagnostics_screen.dart';
import 'services/audio/audio_recorder_service.dart';
import 'services/audio/encrypted_audio_player_service.dart';
import 'services/export/transcript_export_service.dart';
import 'services/storage/storage_quota_service.dart';
import 'services/stt/on_device_draft_stt_service.dart';
import 'services/sync/background_sync_worker.dart';
import 'services/sync/sync_upload_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AutoSyncConnectivityWatcher.initializeBackgroundWorker();
  runApp(const ProviderScope(child: SmartKnowledgeLibraryApp()));
}

// ============================================================================
// مزودات الاعتماديات والحالة (Riverpod Providers)
// ============================================================================

final appLoggerProvider = Provider<AppLoggerService>((ref) {
  return AppLoggerService();
});

final encryptionServiceProvider = Provider<LocalEncryptionService>((ref) {
  return LocalEncryptionService();
});

final hlcClockProvider = Provider<HybridLogicalClock>((ref) {
  return HybridLogicalClock(nodeId: 'mobile-device-01');
});

final conflictResolverProvider = Provider<ConflictResolver>((ref) {
  return ConflictResolver(hlcClock: ref.watch(hlcClockProvider));
});

final exportServiceProvider = Provider<TranscriptExportService>((ref) {
  return TranscriptExportService();
});

final onDeviceDraftSttProvider = Provider<OnDeviceDraftSttService>((ref) {
  return OnDeviceDraftSttService(hlcClock: ref.watch(hlcClockProvider));
});

final localDatabaseProvider = Provider<LocalDatabase>((ref) {
  return LocalDatabase(
    encryptionService: ref.watch(encryptionServiceProvider),
  );
});

final storageQuotaServiceProvider = Provider<StorageQuotaService>((ref) {
  return StorageQuotaService(
    localDb: ref.watch(localDatabaseProvider),
    logger: ref.watch(appLoggerProvider),
  );
});

final syncUploadServiceProvider = Provider<SyncUploadService>((ref) {
  return SyncUploadService(
    localDb: ref.watch(localDatabaseProvider),
    hlcClock: ref.watch(hlcClockProvider),
    simulateCloudInDemoMode: true,
  );
});

final searchQueryProvider = StateProvider<String>((ref) => '');

final entriesListProvider = FutureProvider<List<KnowledgeEntry>>((ref) async {
  final db = ref.watch(localDatabaseProvider);
  final query = ref.watch(searchQueryProvider);
  return db.searchEntries(query);
});

// ============================================================================
// التطبيق الرئيسي (RTL Arabic Material 3)
// ============================================================================

class SmartKnowledgeLibraryApp extends StatelessWidget {
  const SmartKnowledgeLibraryApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'المكتبة المعرفية الذكية',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar', 'SA'),
      supportedLocales: const [Locale('ar', 'SA')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF0F766E),
        brightness: Brightness.light,
      ),
      home: const KnowledgeHomeScreen(),
    );
  }
}

// ============================================================================
// الشاشة الرئيسية: البحث، المزامنة الأوتوماتيكية واليدوية، وقائمة التسجيلات
// ============================================================================

class KnowledgeHomeScreen extends ConsumerStatefulWidget {
  const KnowledgeHomeScreen({super.key});

  @override
  ConsumerState<KnowledgeHomeScreen> createState() =>
      _KnowledgeHomeScreenState();
}

class _KnowledgeHomeScreenState extends ConsumerState<KnowledgeHomeScreen> {
  bool _isSyncing = false;
  late final AutoSyncConnectivityWatcher _connectivityWatcher;

  @override
  void initState() {
    super.initState();
    _connectivityWatcher = AutoSyncConnectivityWatcher(
      syncService: ref.read(syncUploadServiceProvider),
      logger: ref.read(appLoggerProvider),
      onSyncCompleted: () {
        if (mounted) {
          ref.invalidate(entriesListProvider);
        }
      },
    )..startWatching();
  }

  @override
  void dispose() {
    _connectivityWatcher.dispose();
    super.dispose();
  }

  Future<void> _triggerManualSync() async {
    if (_isSyncing) return;
    setState(() => _isSyncing = true);
    try {
      await ref.read(appLoggerProvider).log(
            category: 'UPLOAD_TUS',
            message: 'بدء مزامنة وتفريغ يدوي للتسجيلات المعلقة.',
          );
      final syncedCount =
          await ref.read(syncUploadServiceProvider).syncPendingEntries();
      await ref
          .read(storageQuotaServiceProvider)
          .enforceQuotaOrEvictSyncedAudio();
      ref.invalidate(entriesListProvider);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              syncedCount > 0
                  ? 'تم رفع وتفريغ $syncedCount تسجيلات بنجاح.'
                  : 'جميع التسجيلات متزامنة ومحدّثة.',
            ),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isSyncing = false);
    }
  }

  void _openQuickRecorderModal() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => QuickRecorderSheet(
        onSaved: () async {
          await ref.read(appLoggerProvider).log(
                category: 'AUDIO',
                message: 'تم حفظ وتشفير مقطع صوتي جديد محلياً (≤ دقيقتين).',
              );
          ref.invalidate(entriesListProvider);
          await _triggerManualSync();
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final entriesAsync = ref.watch(entriesListProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('المكتبة المعرفية الذكية'),
        actions: [
          IconButton(
            tooltip: 'مزامنة وتفريغ الآن',
            onPressed: _isSyncing ? null : _triggerManualSync,
            icon: _isSyncing
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.cloud_sync_outlined),
          ),
          IconButton(
            tooltip: 'الإعدادات، السجلات، وجودة التفريغ',
            icon: const Icon(Icons.settings_outlined),
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => const SettingsAndDiagnosticsScreen(),
                ),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'ابحث في التسجيلات والنصوص المفرّغة...',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none,
                ),
              ),
              onChanged: (val) =>
                  ref.read(searchQueryProvider.notifier).state = val,
            ),
          ),
          Expanded(
            child: entriesAsync.when(
              data: (entries) {
                if (entries.isEmpty) {
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                        'لا توجد تسجيلات معرفية بعد.\nاضغط على زر «تسجيل جديد» بالأسفل (حتى دقيقتين للمقطع).',
                        textAlign: TextAlign.center,
                      ),
                    ),
                  );
                }
                return ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: entries.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, idx) {
                    final entry = entries[idx];
                    return Card(
                      elevation: 0.5,
                      child: ListTile(
                        title: Text(
                          entry.title,
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 4),
                            Text(
                              entry.fullTranscriptText,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 6),
                            Wrap(
                              spacing: 8,
                              runSpacing: 4,
                              children: [
                                Chip(
                                  label: Text(entry.syncStatus.arabicLabel),
                                  visualDensity: VisualDensity.compact,
                                ),
                                Chip(
                                  label: Text(
                                    '${entry.durationMs ~/ 1000} ثانية (${entry.audioFormat.toUpperCase()})',
                                  ),
                                  visualDensity: VisualDensity.compact,
                                ),
                                Chip(
                                  label: Text(entry.dialectHint.label),
                                  visualDensity: VisualDensity.compact,
                                ),
                                if (entry.placeName != null)
                                  Chip(
                                    avatar: const Icon(Icons.place, size: 15),
                                    label: Text(entry.placeName!),
                                    visualDensity: VisualDensity.compact,
                                  ),
                              ],
                            ),
                          ],
                        ),
                        onTap: () async {
                          await Navigator.of(context).push(
                            MaterialPageRoute<void>(
                              builder: (_) =>
                                  TranscriptEditorScreen(entryId: entry.id),
                            ),
                          );
                          ref.invalidate(entriesListProvider);
                        },
                      ),
                    );
                  },
                );
              },
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (err, _) => Center(child: Text('حدث خطأ: $err')),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openQuickRecorderModal,
        icon: const Icon(Icons.mic),
        label: const Text('تسجيل جديد (≤ دقيقتين)'),
      ),
    );
  }
}

// ============================================================================
// نافذة التسجيل السريع (مع استئناف + عداد دقيقتين تنازلي + عنوان وموقع اختياري)
// ============================================================================

class QuickRecorderSheet extends ConsumerStatefulWidget {
  final VoidCallback onSaved;

  const QuickRecorderSheet({super.key, required this.onSaved});

  @override
  ConsumerState<QuickRecorderSheet> createState() => _QuickRecorderSheetState();
}

class _QuickRecorderSheetState extends ConsumerState<QuickRecorderSheet> {
  late final AudioRecorderService _recorderService;
  final _titleController = TextEditingController();
  final _placeController = TextEditingController();
  ArabicDialect _selectedDialect = ArabicDialect.auto;
  bool _useWav = false;
  bool _attachLocation = false;

  @override
  void initState() {
    super.initState();
    _recorderService = AudioRecorderService(
      encryptionService: ref.read(encryptionServiceProvider),
      hlcClock: ref.read(hlcClockProvider),
      onMaxDurationReached: (autoSavedEntry) async {
        await ref.read(localDatabaseProvider).insertEntry(autoSavedEntry);
        if (mounted) {
          Navigator.of(context).pop();
          widget.onSaved();
        }
      },
    );
  }

  @override
  void dispose() {
    _titleController.dispose();
    _placeController.dispose();
    _recorderService.dispose();
    super.dispose();
  }

  Future<void> _stopAndSave() async {
    final entry = await _recorderService.stopAndFinalize(
      customTitle: _titleController.text,
      dialect: _selectedDialect,
      placeName: _attachLocation ? _placeController.text : null,
      latitude: _attachLocation ? 24.7136 : null,
      longitude: _attachLocation ? 46.6753 : null,
      quickKeywordsNote: _titleController.text,
      draftSttService: ref.read(onDeviceDraftSttProvider),
    );
    if (entry != null) {
      await ref.read(localDatabaseProvider).insertEntry(entry);
    }
    if (mounted) {
      Navigator.of(context).pop();
      widget.onSaved();
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<RecordingSessionState>(
      stream: _recorderService.stateStream,
      initialData: _recorderService.currentState,
      builder: (context, snapshot) {
        final state = snapshot.data ?? const RecordingSessionState();

        return SingleChildScrollView(
          padding: EdgeInsets.only(
            left: 24,
            right: 24,
            top: 24,
            bottom: MediaQuery.of(context).viewInsets.bottom + 24,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'تسجيل ملاحظة معرفية (الحد الأقصى 02:00)',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 14),
              Text(
                '${state.formattedElapsed} / 02:00',
                style: TextStyle(
                  fontSize: 34,
                  fontWeight: FontWeight.bold,
                  color: state.isNearLimit ? Colors.red : null,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                state.isNearLimit
                    ? 'تنبيه: متبقي ${state.remainingSeconds} ثانية فقط وسيتم الحفظ تلقائياً!'
                    : 'الوقت المتبقي: ${state.formattedRemaining}',
              ),
              const SizedBox(height: 12),
              LinearProgressIndicator(
                value: state.progress,
                minHeight: 8,
                color: state.isNearLimit ? Colors.red : null,
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _titleController,
                decoration: const InputDecoration(
                  labelText: 'عنوان الملاحظة المعرفية (اختياري)',
                  prefixIcon: Icon(Icons.title),
                ),
              ),
              const SizedBox(height: 10),
              if (!state.isRecording) ...[
                DropdownButtonFormField<ArabicDialect>(
                  value: _selectedDialect,
                  decoration: const InputDecoration(
                    labelText: 'اللهجة العربية (لتحسين دقة التفريغ)',
                  ),
                  items: ArabicDialect.values
                      .map(
                        (d) => DropdownMenuItem(
                          value: d,
                          child: Text(d.label),
                        ),
                      )
                      .toList(),
                  onChanged: (val) {
                    if (val != null) setState(() => _selectedDialect = val);
                  },
                ),
                SwitchListTile(
                  title: const Text('إرفاق بيانات الموقع الجغرافي (اختياري)'),
                  value: _attachLocation,
                  onChanged: (v) => setState(() => _attachLocation = v),
                ),
                if (_attachLocation)
                  TextField(
                    controller: _placeController,
                    decoration: const InputDecoration(
                      labelText: 'اسم المكان أو القاعة (مثلاً: مكتبة الجامعة)',
                      prefixIcon: Icon(Icons.place_outlined),
                    ),
                  ),
                SwitchListTile(
                  title: const Text(
                    'تسجيل WAV غير مضغوط (بدلاً من Opus 32kbps)',
                  ),
                  subtitle: const Text(
                    'Opus يوفر ~480KB لدقيقتين مقابل 3.8MB لـ WAV',
                  ),
                  value: _useWav,
                  onChanged: (v) => setState(() => _useWav = v),
                ),
              ],
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  if (!state.isRecording)
                    FilledButton.icon(
                      onPressed: () =>
                          _recorderService.startRecording(useWav: _useWav),
                      icon: const Icon(Icons.fiber_manual_record),
                      label: const Text('بدء التسجيل'),
                    )
                  else ...[
                    IconButton.filledTonal(
                      tooltip: 'إضافة علامة مرجعية زمنية (★ Bookmark)',
                      onPressed: _recorderService.addBookmarkFlag,
                      icon: Badge(
                        isLabelVisible:
                            state.bookmarkTimestampsMs.isNotEmpty,
                        label: Text('${state.bookmarkTimestampsMs.length}'),
                        child: const Icon(Icons.bookmark_add_outlined),
                      ),
                    ),
                    OutlinedButton.icon(
                      onPressed: state.isPaused
                          ? _recorderService.resumeRecording
                          : _recorderService.pauseRecording,
                      icon: Icon(
                        state.isPaused ? Icons.play_arrow : Icons.pause,
                      ),
                      label: Text(state.isPaused ? 'استئناف' : 'إيقاف مؤقت'),
                    ),
                    FilledButton.icon(
                      onPressed: _stopAndSave,
                      icon: const Icon(Icons.check),
                      label: const Text('حفظ وتشفير محلياً'),
                    ),
                  ],
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

// ============================================================================
// شاشة عرض وتحرير التفريغ النصي + مشغل الصوت + التصدير + فض تعارضات الأجهزة
// ============================================================================

class TranscriptEditorScreen extends ConsumerStatefulWidget {
  final String entryId;

  const TranscriptEditorScreen({super.key, required this.entryId});

  @override
  ConsumerState<TranscriptEditorScreen> createState() =>
      _TranscriptEditorScreenState();
}

class _TranscriptEditorScreenState
    extends ConsumerState<TranscriptEditorScreen> {
  KnowledgeEntry? _entry;
  bool _loading = true;
  late final EncryptedAudioPlayerService _audioPlayerService;
  Duration _currentPosition = Duration.zero;
  bool _isAudioReady = false;

  @override
  void initState() {
    super.initState();
    _audioPlayerService = EncryptedAudioPlayerService(
      encryptionService: ref.read(encryptionServiceProvider),
    );
    _audioPlayerService.positionStream.listen((pos) {
      if (mounted) {
        setState(() => _currentPosition = pos);
      }
    });
    _loadEntry();
  }

  @override
  void dispose() {
    _audioPlayerService.dispose();
    super.dispose();
  }

  Future<void> _loadEntry() async {
    final entry =
        await ref.read(localDatabaseProvider).getEntryById(widget.entryId);
    if (entry != null && entry.localFilePath != null) {
      try {
        await _audioPlayerService.loadEncryptedEntry(entry);
        _isAudioReady = true;
      } catch (_) {
        _isAudioReady = false;
      }
    }
    if (mounted) {
      setState(() {
        _entry = entry;
        _loading = false;
      });
    }
  }

  Future<void> _exportEntry(TranscriptExportFormat format) async {
    final entry = _entry;
    if (entry == null) return;
    final exporter = ref.read(exportServiceProvider);
    final file = await exporter.exportEntryToFile(entry, format);
    final content = exporter.formatEntry(entry, format);
    await Clipboard.setData(ClipboardData(text: content));

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'تم التصدير بصيغة ${format.arabicLabel} إلى: ${file.path} (ونسخه للحافظة)',
          ),
        ),
      );
    }
  }

  /// نافذة تفاعلية لحل تعارض تعديل نفس الفقرة بين جهازين مختلفين
  Future<void> _openConflictResolutionDialog(TranscriptSegment segment) async {
    final resolver = ref.read(conflictResolverProvider);
    final conflict = resolver.createSimulatedConflict(segment);

    final chosenText = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حل تعارض التعديل بين الأجهزة (HLC Conflict)'),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'تم رصد تعديلين مختلفين على هذه الفقرة من جهازين قبل الاتصال بالإنترنت:',
              ),
              const SizedBox(height: 12),
              Card(
                child: ListTile(
                  title: const Text('نسخة هذا الجهاز (Local):'),
                  subtitle: Text(conflict.localSegment.editedText),
                  onTap: () =>
                      Navigator.pop(context, conflict.localSegment.editedText),
                ),
              ),
              const SizedBox(height: 8),
              Card(
                child: ListTile(
                  title: const Text('نسخة الجهاز الآخر (Remote):'),
                  subtitle: Text(conflict.remoteSegment.editedText),
                  onTap: () =>
                      Navigator.pop(context, conflict.remoteSegment.editedText),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          FilledButton.tonal(
            onPressed: () {
              final merged = resolver.mergeBothVersions(conflict);
              Navigator.pop(context, merged.editedText);
            },
            child: const Text('دمج النسختين معاً'),
          ),
        ],
      ),
    );

    if (chosenText != null && _entry != null) {
      final hlc = ref.read(hlcClockProvider).now();
      await ref.read(localDatabaseProvider).updateSegmentText(
            entryId: _entry!.id,
            segmentId: segment.id,
            newText: chosenText,
            hlcTimestamp: hlc,
          );
      await _loadEntry();
    }
  }

  Future<void> _editSegmentDialog(TranscriptSegment segment) async {
    final controller = TextEditingController(text: segment.editedText);
    final updated = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('تعديل الفقرة [${segment.formattedStartTime}]'),
        content: TextField(
          controller: controller,
          maxLines: 5,
          decoration: const InputDecoration(
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: const Text('حفظ التعديل'),
          ),
        ],
      ),
    );

    if (updated != null && updated.isNotEmpty && _entry != null) {
      final hlc = ref.read(hlcClockProvider).now();
      await ref.read(localDatabaseProvider).updateSegmentText(
            entryId: _entry!.id,
            segmentId: segment.id,
            newText: updated,
            hlcTimestamp: hlc,
          );
      await ref.read(appLoggerProvider).log(
            category: 'SYNC_HLC',
            message: 'تم تعديل الفقرة يدوياً وحمايتها بطابع HLC.',
            metrics: {'segment_id': segment.id, 'hlc': hlc},
          );
      await _loadEntry();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final entry = _entry;
    if (entry == null) {
      return Scaffold(
        appBar: AppBar(),
        body: const Center(child: Text('لم يتم العثور على التسجيل.')),
      );
    }

    final activeSegmentIdx = _audioPlayerService.findActiveSegmentIndex(
      entry.segments,
      _currentPosition,
    );

    return Scaffold(
      appBar: AppBar(
        title: Text(entry.title),
        actions: [
          PopupMenuButton<TranscriptExportFormat>(
            tooltip: 'تصدير التفريغ النصي',
            icon: const Icon(Icons.ios_share),
            onSelected: _exportEntry,
            itemBuilder: (context) => TranscriptExportFormat.values
                .map(
                  (fmt) => PopupMenuItem(
                    value: fmt,
                    child: Text(fmt.arabicLabel),
                  ),
                )
                .toList(),
          ),
          IconButton(
            tooltip: 'نسخ النص الكامل مع الطوابع الزمنية',
            icon: const Icon(Icons.copy_all),
            onPressed: () {
              Clipboard.setData(
                ClipboardData(text: entry.fullTranscriptWithTimestamps),
              );
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('تم نسخ النص المنسق مع الطوابع الزمنية.'),
                ),
              );
            },
          ),
        ],
      ),
      bottomNavigationBar: _isAudioReady
          ? BottomAppBar(
              child: Row(
                children: [
                  IconButton(
                    icon: Icon(
                      _audioPlayerService.isPlaying
                          ? Icons.pause_circle_filled
                          : Icons.play_circle_filled,
                      size: 36,
                    ),
                    onPressed: () async {
                      if (_audioPlayerService.isPlaying) {
                        await _audioPlayerService.pause();
                      } else {
                        await _audioPlayerService.play();
                      }
                      setState(() {});
                    },
                  ),
                  Expanded(
                    child: Slider(
                      value: _currentPosition.inMilliseconds
                          .toDouble()
                          .clamp(0.0, entry.durationMs.toDouble()),
                      max: entry.durationMs.toDouble().clamp(1000.0, 120000.0),
                      onChanged: (val) =>
                          _audioPlayerService.seekToMs(val.toInt()),
                    ),
                  ),
                  Text(
                    '${(_currentPosition.inSeconds ~/ 60).toString().padLeft(2, '0')}:${(_currentPosition.inSeconds % 60).toString().padLeft(2, '0')}',
                  ),
                ],
              ),
            )
          : null,
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: entry.segments.length,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (context, index) {
          final seg = entry.segments[index];
          final isHighlighted = activeSegmentIdx == index;

          return Card(
            color: isHighlighted
                ? Theme.of(context).colorScheme.primaryContainer
                : null,
            child: InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: _isAudioReady
                  ? () => _audioPlayerService.seekToMs(seg.startMs)
                  : null,
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        ActionChip(
                          avatar: const Icon(Icons.play_arrow, size: 16),
                          label: Text(seg.formattedStartTime),
                          onPressed: _isAudioReady
                              ? () => _audioPlayerService.seekToMs(seg.startMs)
                              : null,
                        ),
                        Row(
                          children: [
                            if (seg.isUserModified)
                              const Padding(
                                padding: EdgeInsets.only(left: 6),
                                child: Chip(
                                  label: Text('معدّل يدوياً'),
                                  visualDensity: VisualDensity.compact,
                                ),
                              ),
                            IconButton(
                              tooltip: 'حل تعارض الأجهزة (HLC Merge)',
                              icon: const Icon(Icons.merge_type, size: 20),
                              onPressed: () =>
                                  _openConflictResolutionDialog(seg),
                            ),
                            IconButton(
                              tooltip: 'نسخ الفقرة',
                              icon: const Icon(Icons.copy, size: 18),
                              onPressed: () {
                                Clipboard.setData(
                                  ClipboardData(text: seg.editedText),
                                );
                              },
                            ),
                            IconButton(
                              tooltip: 'تحرير النص',
                              icon: const Icon(Icons.edit_outlined, size: 20),
                              onPressed: () => _editSegmentDialog(seg),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    SelectableText(
                      seg.editedText,
                      style: const TextStyle(fontSize: 16, height: 1.6),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
