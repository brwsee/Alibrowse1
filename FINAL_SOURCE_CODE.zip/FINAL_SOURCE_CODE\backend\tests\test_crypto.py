import os

import pytest

from app.crypto import CryptoError, KeyManager, decrypt_file, encrypt_bytes, wrap_key


@pytest.mark.parametrize("size", [0, 1, 4095, 4096, 4097, 50_000])
def test_roundtrip(tmp_path, size):
    dek = os.urandom(32)
    plain = os.urandom(size)
    src, dst = tmp_path / "x.bin", tmp_path / "x.wav"
    src.write_bytes(encrypt_bytes(plain, dek, chunk_size=4096))
    assert decrypt_file(src, dst, dek) == size
    assert dst.read_bytes() == plain


def test_truncation_detected(tmp_path):
    dek = os.urandom(32)
    blob = encrypt_bytes(os.urandom(10_000), dek, chunk_size=4096)
    src = tmp_path / "x.bin"
    # احذف المقطع الأخير بالكامل: يجب أن يفشل لأن المقطع الذي صار أخيراً لم يُوسم كذلك
    src.write_bytes(blob[: 21 + 2 * (4096 + 16)])
    with pytest.raises(CryptoError):
        decrypt_file(src, tmp_path / "o", dek)


def test_tamper_detected(tmp_path):
    dek = os.urandom(32)
    blob = bytearray(encrypt_bytes(b"hello world" * 100, dek, chunk_size=1024))
    blob[40] ^= 0xFF
    src = tmp_path / "x.bin"
    src.write_bytes(bytes(blob))
    with pytest.raises(CryptoError):
        decrypt_file(src, tmp_path / "o", dek)


def test_key_wrap(tmp_path):
    km = KeyManager(tmp_path)
    dek = os.urandom(32)
    assert km.unwrap(wrap_key(km.public_key(), dek), km.key_id) == dek
    with pytest.raises(CryptoError):
        km.unwrap(wrap_key(km.public_key(), dek), "other")
    # المفتاح يُحمَّل من القرص بنفس المعرّف
    assert KeyManager(tmp_path).key_id == km.key_id


def test_jwk_shape(tmp_path):
    jwk = KeyManager(tmp_path).public_jwk()
    assert jwk["kty"] == "RSA" and jwk["e"] == "AQAB" and len(jwk["n"]) > 500
