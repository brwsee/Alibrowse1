from app.arabic import normalize_for_matching, strip_fillers, tidy_punctuation
from app.quality import cer, wer
from app.segmenter import segment_words
from app.stt.base import Word
from app.stt.gemini_provider import parse_offset_ms


def test_normalization_folds_orthographic_variants():
    assert normalize_for_matching("إِلَى المَدْرَسَةِ") == normalize_for_matching("الى المدرسه")
    assert normalize_for_matching("مُسْتَشْفى ١٢٣") == "مستشفي 123"
    assert normalize_for_matching("قالَ: «نعم»، حسناً!") == "قال نعم حسنا"


def test_wer_ignores_diacritics_and_punctuation():
    assert wer("ذَهَبَ الوَلَدُ إلى المدرسة.", "ذهب الولد الى المدرسه").rate == 0.0


def test_wer_counts_edits():
    e = wer("ذهب الولد الى المدرسة", "ذهب البنت الى")
    assert (e.substitutions, e.deletions, e.insertions) == (1, 1, 0)
    assert e.rate == 0.5
    assert wer("", "").rate == 0.0
    assert wer("", "كلمة").rate == 1.0


def test_cer():
    assert cer("كتاب", "كتب").rate == 0.25


def test_fillers_and_punctuation():
    assert strip_fillers("اممم اليوم آه نتكلم") == "اليوم نتكلم"
    assert tidy_punctuation("هل انت جاهز ?") == "هل انت جاهز؟"
    assert tidy_punctuation("مرحبا , كيف الحال") == "مرحبا، كيف الحال."


def test_offset_parsing():
    assert parse_offset_ms("0.100s") == 100
    assert parse_offset_ms("12.3456s") == 12346
    assert parse_offset_ms(None) is None
    assert parse_offset_ms("bad") is None


def test_segmenter_breaks_on_pause_and_speaker():
    words = [
        Word("السلام", 0, 400, "a"), Word("عليكم", 450, 900, "a"),
        Word("اليوم", 2500, 2900, "a"), Word("نتكلم", 2950, 3400, "a"),
        Word("تمام", 3500, 3900, "b"),
    ]
    paras = segment_words(words, pause_ms=700, offset_ms=10_000)
    assert [p.text for p in paras] == ["السلام عليكم.", "اليوم نتكلم.", "تمام."]
    assert (paras[0].start_ms, paras[0].end_ms) == (10_000, 10_900)
    assert paras[2].speaker == "b"


def test_segmenter_hard_limit():
    words = [Word(f"w{i}", i * 100, i * 100 + 90) for i in range(1000)]  # 100 ثانية بلا صمت
    paras = segment_words(words, pause_ms=700, max_ms=30_000)
    assert len(paras) >= 2
    assert all(p.end_ms - p.start_ms <= 60_000 for p in paras)
